<?php

    session_start();
    if(!isset($_SESSION['parent'])) {
        die();
    }

    $student_id = $_SESSION['parent_student_id'];

    function sanitize($str, $html_tags_remove = 1) {
        $search  = array('\\', "'", '"');
        $replace = array('\\\\', "\'", '\"');
        $str = trim($str);
        $str = str_replace($search, $replace, $str);
        if($html_tags_remove == 1)
            $str = htmlentities($str);
            
        return $str;
    }

    include "../../admin/database_connection.php";

    $result = array();

    if(@is_numeric($_POST['like']) && @is_numeric($_POST['live_id'])) {
        $like = ($_POST['like'] == 1) ? 1 : 0;
        $live_id = $_POST['live_id'];
        $update = $connect->query("UPDATE live_video SET parent_liked = $like WHERE ID = $live_id AND student_id = $student_id");

        if($update->rowCount() > 0) {
            $result['success'] = 'success';
        }
    }
    
    if(!empty($_POST['comment']) && @is_numeric($_POST['live_id'])) {
        $result ['comment'] = $comment = sanitize($_POST['comment']);
        $live_id = $_POST['live_id'];

        $result ['date'] = $date = date('Y-m-d H:i:s');

        $check = $connect->query("SELECT * FROM live_video WHERE student_id = '$student_id' AND ID = '$live_id'");

        if($check->rowCount() > 0) {
            $insert = $connect->query("INSERT INTO live_video_comments SET comment = '$comment', comment_date = '$date', user_type = 'parent',
                                        user_id = '$student_id', live_id = '$live_id'");

            if($insert->rowCount() > 0) {
                $result['success'] = 'success';
                add_notification("Parent", $_SESSION["parent_student_id"], $_SESSION['student_name'], "قام ولي الأمر بإضافة تعليق على البث المباشر :<br>$comment", "No changes");
            }
        }

    }

    echo json_encode($result);