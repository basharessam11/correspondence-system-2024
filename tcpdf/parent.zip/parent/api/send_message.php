<?php

    session_start();
    if(!isset($_SESSION['parent'])) {
        die();
    }

    $student_id = $_SESSION['parent_student_id'];

    include "../../admin/database_connection.php";

    function sanitize($str, $html_tags_remove = 1) {
        $search  = array('\\', "'", '"');
        $replace = array('\\\\', "\'", '\"');
        $str = trim($str);
        $str = str_replace($search, $replace, $str);
        if($html_tags_remove == 1)
            $str = htmlentities($str);
            
        return $str;
    }

    $teacher_id = @$connect->query("SELECT tbl_teacher.teacher_id FROM tbl_student 
                                    INNER JOIN tbl_teacher ON tbl_student.student_grade_id = tbl_teacher.teacher_grade_id 
                                    WHERE student_id = $student_id")->fetchAll()[0]['teacher_id'];

    $result = array();

    if(!empty($_POST['message'])) {

        $result['message'] = $message = sanitize($_POST['message']);

        $result['date'] = $date = date("Y-m-d H:i:s");

        $result['attachments'] = $attachments = array();

        $attachments = base64_encode(json_encode($attachments));

        $insert = $connect->query("INSERT INTO parent_teacher_messages SET message = '$message', date_sent = '$date', attachments = '$attachments',
                        user_type = 'parent', student_id = $student_id, teacher_id = $teacher_id");

        $ACTION =  'قام ولي أمر الطالب '.$_SESSION['student_name'].' بإرسال رسالة للمعلم: <br>'.$_POST['message'];

        add_notification('Parent', $student_id, $_SESSION['student_name'], $ACTION, "No changes");
        
        if($insert->rowCount() > 0) {
            $result['success'] = 'success';
        }
    }
    
    echo json_encode($result);