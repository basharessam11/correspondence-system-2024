<?php

    function sanitize($str, $html_tags_remove = 1) {
        $search  = array('\\', "'", '"');
        $replace = array('\\\\', "\'", '\"');
        $str = trim($str);
        $str = str_replace($search, $replace, $str);
        if($html_tags_remove == 1)
          $str = strip_tags($str);
            
        return $str;
    }
    

    (isset($_POST['database'])) ? $ajax_dbname = $_POST['database'] : '';
    (isset($_POST['db_ui_name'])) ? $ajax_db_ui_name = $_POST['db_ui_name'] : '';

    if(isset($_POST['student_clid'])) {
        $result = array();

        $json = file_get_contents('../../admin/databases.json');
        $databases = json_decode($json, TRUE);
        $database_found = false;
        foreach($databases as $database_arr) {
            if($database_arr['db_name'] == $ajax_dbname && @$database_arr['active'] != 0) {
                $ajax_db_ui_name = $database_arr['title'];
                $database_found = true;
                break;
            }
        }

        if(!$database_found)
            $result['error'] = 'Wrong Database';
        else {
            include "../../admin/database_connection.php";
            $clid = sanitize($_POST['student_clid']);
            $student = @$connect->query("SELECT student_id, student_name, is_active FROM tbl_student WHERE clid = '$clid'")->fetchAll()[0];
            if(!empty($student)) {
                if($student['is_active'] == 0) {
                    $result['error'] = 'not active';
                } else {
                    session_start();
                    $_SESSION['parent'] = TRUE;
                    $_SESSION['clid'] = $clid;
                    $_SESSION['parent_student_id'] = $student['student_id'];
                    $_SESSION['student_name'] = $student['student_name'];
                    $_SESSION['database'] = $_POST['database'];
                    $_SESSION['db_ui_name'] = $ajax_db_ui_name;
                    $_SESSION['login_time'] = $_POST['login_time'];
                    $result['success'] = 'success';
                    $USER_TYPE = 'Parent';
                    @add_notification($USER_TYPE, $student["student_id"], $student["student_name"], 'تسجيل الدخول', "No changes");
                }
            } else {
                $result['error'] = 'wrong clid';
            }
        }
        
        echo json_encode($result);
    }