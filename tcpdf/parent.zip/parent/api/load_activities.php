<?php


    session_start();

    if(!isset($_SESSION['parent'])) {
        die(header("location: login.php"));
    }

    include "../../admin/database_connection.php";

    $student_id = $_SESSION['parent_student_id'];

    $result = array();

    $skip = (@is_numeric($_POST['loaded'])) ? $_POST['loaded'] : 0;
    $and_activity_id = (@is_numeric($_POST['activity_id'])) ? ' AND activity_id = '.$_POST['activity_id'] : '';

    $student_activities = $connect->query("SELECT student_activities.*, tbl_teacher.teacher_name, tbl_specialist.specialist_name
                                            FROM student_activities
                                            LEFT JOIN tbl_teacher ON tbl_teacher.teacher_id = student_activities.teacher_id
                                            LEFT JOIN tbl_specialist ON tbl_specialist.specialist_id = student_activities.teacher_id
                                            WHERE student_id = $student_id $and_activity_id
                                            ORDER BY activity_date DESC
                                            LIMIT $skip, 5")->fetchAll();

    if(count($student_activities) == 0) 
        echo ($skip == 0) ? '<h4 class="text-center py-5">لا يوجد أنشطة للطالب حالياً</h4>' : '';
    
    foreach($student_activities as $activity) {

        $connect->query("UPDATE student_activities SET seen_by_parent = 1 WHERE activity_id = ".$activity['activity_id']);

        $activity_media = $activity['activity_media'] = json_decode(base64_decode($activity['activity_media']), TRUE);
        
        ?>
        <div class="activity text-right" id="activity<?php echo $activity['activity_id'] ?>">
            <h4 class="title"><?php echo $activity['activity_title']; ?></h4>
            <p class="date"><?php echo $activity['activity_date']; ?></p>
            <?php if($activity['teacher_type'] == 'specialist') { ?> 
                <p class="title">الأخصائي : <?php echo $activity['specialist_name']; ?></p>
            <?php } else { ?>
                <p class="title">المعلم : <?php echo $activity['teacher_name']; ?></p>
            <?php } ?>
            <p class="description"><?php echo str_replace("\n", "<br>", $activity['activity_description']); ?></p>
            <div class="media-items">
                <?php 
                if(!empty($activity['activity_iframe'])) { 
                    echo "<div class='text-center'>".$activity['activity_iframe']."</div>"; 
                } else { ?>
                    <?php for($i = 0; $i < count($activity_media); $i++) { ?>
                        <?php
                        $media_type = explode(".", $activity_media[$i]);
                        $media_type = $media_type[count($media_type)-1];
                        if(in_array($media_type, array('mp4', 'mov'))) { ?>
                            <div class="media-item">
                            <video controls>
                                <source src="../student_activities/<?php echo $activity_media[$i]; ?>" type="video/mp4">
                                Your browser does not support the video tag.
                            </video>
                            </div>
                        <?php } elseif(in_array($media_type, array('mp3'))) { ?>
                            <div class="media-item media-audio">
                            <audio controls style="width: 100%;height: 100%;">
                                <source src="../student_activities/<?php echo $activity_media[$i]; ?>" type="audio/mpeg">
                                Your browser does not support the audio element.
                            </audio>
                            </div>
                        <?php } else { ?>
                            <div class="media-item">
                            <img src="../student_activities/<?php echo $activity_media[$i]; ?>">
                            </div>
                        <?php } ?>
                    <?php } ?>
                <?php } ?>
                <?php if(count($activity_media) > 1) { ?> 
                    <p class="text-center"><a href="#" class="show-more" data-action='more'>عرض المزيد</a></p>                
                <?php } ?>
            </div>
            <div class="row mt-3">
                <div class="col-6">
                    <button class="add-like w-100<?php echo ($activity['parent_liked'] == 1) ? ' liked' : ''; ?>" data-activity-id="<?php echo $activity['activity_id'] ?>">
                        
                        <?php echo ($activity['parent_liked'] == 1) ? ' <i class="fas fa-thumbs-up"></i> إلغاء' : '<i class="far fa-thumbs-up"></i> إعجاب'; ?>
                    </button>
                </div>
                <div class="col-6">
                    <button class="add-comment w-100" data-activity-id="<?php echo $activity['activity_id'] ?>"><i class="far fa-comment-dots"></i> تعليق</button>
                </div>
            </div>
            <div class="mt-3">
                <?php 
                $comments = $connect->query("SELECT student_activity_comments.*, tbl_teacher.teacher_name, tbl_specialist.specialist_name 
                                        FROM student_activity_comments 
                                        LEFT JOIN tbl_teacher ON tbl_teacher.teacher_id = student_activity_comments.user_id
                                        LEFT JOIN tbl_specialist ON tbl_specialist.specialist_id = student_activity_comments.user_id
                                        WHERE activity_id = ".$activity['activity_id']." ORDER BY comment_date DESC")->fetchAll();
                ?>
                <legend>التعليقات (<span class="comments_num"><?php echo count($comments) ?></span>)</legend>
                <form class="type-box row pb-2 send_comment_form" data-activity-id="<?php echo $activity['activity_id'] ?>" method="post">
                    <div class="col-12 col-lg-10">
                        <textarea name="comment" class="form-control" rows="3" placeholder="تعليقك..."></textarea>
                    </div>
                    <div class="col-12 col-lg-2 text-center">
                        <button type="submit" class="form-control btn btn-success mt-2 send_comment"><i class="fas fa-paper-plane"></i></button>
                    </div>
                </form>
                <div class="comments">
                    <?php
                    foreach ($comments as $comment) { 
                        
                        $connect->query("UPDATE student_activity_comments SET seen_by_parent = 1 WHERE comment_id = ".$comment['comment_id']);
                        if($comment['user_type'] == 'specialist') {
                            $user = 'المتخصص: '. $comment['specialist_name'];
                        } elseif ($comment['user_type'] == 'teacher') {
                            $user = 'المعلم: '. $comment['teacher_name'];
                        } elseif ($comment['user_type'] == 'parent') {
                            $user = 'أنت: ';
                        } else {
                            $user = '';
                        }
                    ?>
                    <div class="comment" id="comment<?php echo $comment['comment_id']; ?>">
                        <div class="comment-info">
                            <strong><?php echo $user; ?></strong>
                            <p class="date"><?php echo $comment['comment_date']; ?></p>
                        </div>
                        <div class="comment-text pr-3">
                            <?php echo str_replace("\n", "<br>", $comment['comment']); ?>
                        </div>
                    </div>
                    <?php } ?>
                    
                </div>
            </div>
        </div>

        <?php
    }
