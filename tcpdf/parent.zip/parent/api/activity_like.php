<?php

    session_start();
    if(!isset($_SESSION['parent'])) {
        die();
    }

    $student_id = $_SESSION['parent_student_id'];

    include "../../admin/database_connection.php";

    $result = array();

    if(@is_numeric($_POST['like']) && @is_numeric($_POST['activity_id'])) {
        $like = ($_POST['like'] == 1) ? 1 : 0;
        $activity_id = $_POST['activity_id'];
        $update = $connect->query("UPDATE student_activities SET parent_liked = $like WHERE activity_id = $activity_id AND student_id = $student_id");

        if($update->rowCount() > 0) {
            $result['success'] = 'success';
        }
    }

    echo json_encode($result);