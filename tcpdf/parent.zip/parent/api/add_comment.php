<?php

    session_start();
    if(!isset($_SESSION['parent'])) {
        die();
    }

    $student_id = $_SESSION['parent_student_id'];

    function sanitize($str, $html_tags_remove = 1) {
        $search  = array('\\', "'", '"');
        $replace = array('\\\\', "\'", '\"');
        $str = trim($str);
        $str = str_replace($search, $replace, $str);
        if($html_tags_remove == 1)
            $str = htmlentities($str);
            
        return $str;
    }
    
    $result = array();

    if(!empty($_POST['comment']) && @is_numeric($_POST['activity_id'])) {
        $result ['comment'] = $comment = sanitize($_POST['comment']);
        $activity_id = $_POST['activity_id'];

        include "../../admin/database_connection.php";

        $result ['date'] = $date = date('Y-m-d H:i:s');

        $check = $connect->query("SELECT * FROM student_activities WHERE student_id = '$student_id' AND activity_id = '$activity_id'");

        if($check->rowCount() > 0) {
            $insert = $connect->query("INSERT INTO student_activity_comments SET comment = '$comment', comment_date = '$date', user_type = 'parent',
                                        user_id = '$student_id', activity_id = '$activity_id'");

            if($insert->rowCount() > 0) {
                $result['success'] = 'success';
                add_notification("Parent", $_SESSION["parent_student_id"], $_SESSION['student_name'], "قام ولي الأمر بإضافة تعليق على نشاط الطالب :<br>$comment", "No changes");
            }
        }

    }
    echo json_encode($result);
