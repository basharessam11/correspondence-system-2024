<?php

//login.php

session_start();

if(isset($_SESSION["parent"]))
{
  die(header('location:index.php'));
}

include "../admin/database_connection.php";
if(isset($_SESSION['staff_id'])) {
  $USER_TYPE = 'Staff';
  $username = $_SESSION['staff_user_name'];
  $user_id = $_SESSION['staff_id'];
}
elseif(isset($_SESSION['teacher_id'])) {
  $USER_TYPE = 'Teacher';
  $username = $_SESSION['teacher_name'];
  $user_id = $_SESSION['teacher_id'];
}
elseif(isset($_SESSION['specialist_id'])) {
  $USER_TYPE = 'Specialist';
  $username = $_SESSION['specialist_name'];
  $user_id = $_SESSION['specialist_id'];
}
elseif(isset($_SESSION['attendance_supervisor_id'])) {
  $USER_TYPE = 'Attendance Supervisor';
  $username = $_SESSION['attendance_supervisor_name'];
  $user_id = $_SESSION['attendance_supervisor_id'];
}


if(isset($USER_TYPE)) {
  $ACTION = "حاول الدخول إلى واجهة ولي الأمر";
  add_notification($USER_TYPE, $user_id, $username, $ACTION, "No changes");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>نظام ادارة بيانات الطلاب</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <script src="../js/main.js"></script>
</head>
<style>


img {
  border-radius: 100%;
}


body {
  background-color: SlateGray;
}
</style>
<body>

<div class="text-center my-2" style="margin-bottom:0" dir="rtl" align="center">
  <img src="../<?php echo "img/".Logo; ?>" width=100 class="logo d-block m-auto">
  <h3><?php echo Website_name; ?></h3>
  <h5><?php echo Website_name_en; ?></h5>
</div>



<div class="container">
  <div class="row">
    <div class="col-md-4">

    </div>
    <div class="col-md-4" style="margin-top:20px;">
      <div class="card">
        <div class="card-header">Access Denied</div>
        <div class="card-body text-center">
        أنت الآن متصل بحساب آخر، لا يحق لك الولوج إلى واجهة ولي الأمر<br/>
        </div>
      </div>
    </div>
    <div class="col-md-4">

    </div>
  </div>
</div>

</body>
</html>
