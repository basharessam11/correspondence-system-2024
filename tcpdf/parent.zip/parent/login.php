<?php

    session_start();

    if(isset($_SESSION['parent'])) {
        die(header("location: index.php"));
    }
    include "../admin/database_connection.php";

    $maintenance_mode = $connect->query("SELECT value FROM variables WHERE name = 'maintenance_mode'")->fetchAll()[0]['value'];
    if($maintenance_mode == 1) {
        die(header("location: ../index.php"));
    }
?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> دخول ولي الأمر</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
    <script src="../js/main.js?v=<?php echo time(); ?>"></script>
</head>
<body dir="rtl">

    <div class="container text-center">
        <form action="" method="post" class="my-3 p-4" id="login" style="display:none">
            <img src="../<?php echo "img/".Logo; ?>" alt="Logo" width=140 id="logo">
            <h3 class="my-3">تسجيل دخول ولي الأمر</h3>
            <div class="form-group">
              <label>العام الدراسي</label>
              <input type="hidden" name="db_ui_name">
              <select name="database" class="form-control" required>
                <option value="">اختر العام الدراسي</option>
                <?php 
                $json = file_get_contents('../admin/databases.json');
                $databases = json_decode($json, TRUE);
                foreach($databases as $database) {
                  if(!isset($database['active']) || $database['active'] == 1)
                    echo '<option value="'.$database['db_name'].'">'.$database['title'].'</option>';
                }
                ?>
              </select>
            </div>
            <div class="form-group">
                <label for="student_clid" class="mt-3">الرقم المدني الطالب</label>
                <input type="text" name="student_clid" id="student_clid" placeholder="">
                <text class="text-danger" id="error" style="display:none"></text>
                <button class="btn btn-primary mt-3">دخول</button>
            </div>
        </form>
    </div>

    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            var db_val = $("select[name=database]").val();
            if(db_val != "") {
                var db_ui_name = $("select[name=database] option[value="+db_val+"]").text();
                $("[name=db_ui_name]").val(db_ui_name);
            }
            
            $("select[name=database]").on("change", function() {
                var val = $(this).val();
                var db_ui_name = $("select[name=database] option[value="+val+"]").text();
                $("[name=db_ui_name]").val(db_ui_name);
            })
          $("#login").fadeIn(500);
            
            $("#login").on("submit", function(e) {
                e.preventDefault();
                var date = new Date;
                var seconds = date.getSeconds();
                var minutes = date.getMinutes();
                var hour = date.getHours();
                var login_time = hour+":"+minutes+":"+seconds;
                $.ajax({
                    type:"POST",
                    url:"api/check_login.php",
                    data:{database:$("[name=database]").val(), student_clid:$("[name=student_clid]").val(), login_time},
                    dataType:"json",
                    success:function(data) {
                        if(data.success == 'success') {
                            $("#login").fadeOut(500);
                            window.location = 'index.php';
                        } else if(data.error == 'wrong clid') {
                            $("#error").text('الرقم المدني خاطئ').fadeIn(500);
                        } else if(data.error == 'not active') {
                            $("#error").text('الحساب غير نشط').fadeIn(500);
                        }
                    }
                })
            })
          
          <?php
            if(isset($_COOKIE['parent']) && isset($_COOKIE['database'])) {
                $clid = $_COOKIE['clid'];
                $database = $_COOKIE['database'];
                echo '$("select[name=database]").val("'.$database.'");';
                echo '$("[name=student_clid]").val("'.$clid.'");';
                echo '$("#login").trigger("submit");';
            }
            ?>
        })
    </script>
</body>
</html>