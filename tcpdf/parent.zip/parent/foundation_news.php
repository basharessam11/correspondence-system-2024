<?php

    include "header.php";

    $foundation_news = $connect->query("SELECT value FROM variables WHERE name = 'foundation_news'")->fetchAll()[0]['value'];
?>

<div class="container bg-white p-3 my-3">
    <?php echo $foundation_news; ?>
</div>