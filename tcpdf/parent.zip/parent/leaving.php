<?php

    include "header.php";

$date = date("Y-m-d");
if(@is_numeric($_POST['time_to_arrive'])) {
    $mins= $_POST['time_to_arrive'];
    $teacher = $connect->query("SELECT tbl_teacher.*, student_name FROM tbl_student INNER JOIN tbl_teacher ON tbl_student.student_grade_id = tbl_teacher.teacher_grade_id WHERE student_id = $student_id")->fetchAll()[0];
    $teacher_id = $teacher['teacher_id'];
    $teacher_phone = $teacher['teacher_phone'];
    $teacher_email = $teacher['teacher_emailid'];
    $student_name = $teacher['student_name'];
    $message = 'ولي أمر الطالب <strong>"'.$student_name.'"</strong> سيصل في خلال '.$mins.' دقائق';
    $now = date("Y-m-d H:i:s");
    // $link = "https://www.kwtsms.com/API/send/?username=ican&password=Ican2020&sender=Icankuwait&mobile=+965".$teacher_phone."&lang=3&message=".urlencode($_POST['message']);
    // $send = file_get_contents($link);
    // if(strpos($send,"OK:") !== FALSE) {
        // $delete_old = $connect->query("DELETE FROM student_leaving WHERE student_id = $student_id AND date LIKE '$date%'");
        // $insert = $connect->query("INSERT INTO student_leaving SET student_id = $student_id, teacher_id = $teacher_id, minutes = $mins, date = NOW()");
    // }
    
    $headers  = "From: Student Ican <studentican@srsforward.aba.ae>\n";
    $headers .= "Cc: Student Ican <studentican@srsforward.aba.ae>\n"; 
    $headers .= "X-Sender: Student Ican <studentican@srsforward.aba.ae>\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\n";
    $mail = @mail($teacher_email, "ولي الأمر في الطريق", $message, $headers);

    if($mail) {
        $delete_old = $connect->query("DELETE FROM student_leaving WHERE student_id = $student_id AND date LIKE '$date%'");
        $insert = $connect->query("INSERT INTO student_leaving SET student_id = $student_id, teacher_id = $teacher_id, minutes = $mins, date = '$now'");
    }

}
$check = $connect->query("SELECT * FROM student_leaving WHERE student_id = $student_id AND date LIKE '$date%'")->rowCount();
?>

<div class="container my-3 py-5 bg-light text-center">
    <h3 class="mb-4">الإنصراف</h3>
    <?php if($check > 0) {
        echo '<div class="alert alert-success">تم تنبيه المعلم بوصلك</div>';
    } ?>
    <form action="" method="post">
        في خلال 
        <select name="time_to_arrive" class="form-control d-inline-block" style="width:70px">
            <option value="5">5</option>
            <option value="10">10</option>
            <option value="15">15</option>
        </select>
        دقائق سأكون عند البوابة
        <div class="mt-4">
        <button type="submit" class="btn btn-primary">إرسال للمعلم</button>
        </div>
    </form>
</div>