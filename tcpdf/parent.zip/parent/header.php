<?php

session_start();

if(!isset($_SESSION['admin_id']))
if(isset($_SESSION["teacher_id"]) || isset($_SESSION["staff_id"]) || isset($_SESSION["specialist_id"]) || isset($_SESSION["attendance_supervisor_id"]))
{
  die(header('location:access_denied.php'));
}

if(!isset($_SESSION['parent'])) {
    die(header("location: login.php"));
}

$student_id = $_SESSION['parent_student_id'];
$ajax_dbname = $_SESSION['database'];
$ajax_db_ui_name = $_SESSION['db_ui_name'];

include "../admin/database_connection.php";

$maintenance_mode = $connect->query("SELECT value FROM variables WHERE name = 'maintenance_mode'")->fetchAll()[0]['value'];
if($maintenance_mode == 1) {
  die(header("location: ../index.php"));
}

if(!isset($_COOKIE['parent'])) {
    setcookie('parent', 'parent', time()+3600*24*30);
    setcookie('clid', $_SESSION['clid'], time()+3600*24*30);
    setcookie('database', $_SESSION['database'], time()+3600*24*30);
}

$notifications = $connect->query("SELECT student_activities.*, tbl_teacher.teacher_name, tbl_teacher.teacher_id, tbl_teacher.teacher_image
                                FROM student_activities 
                                INNER JOIN tbl_teacher ON tbl_teacher.teacher_id = student_activities.teacher_id
                                WHERE student_id = $student_id AND student_activities.seen_by_parent = 0")->fetchAll();

$notifications2 = $connect->query("SELECT student_activities.*, tbl_teacher.teacher_name, tbl_teacher.teacher_id, tbl_teacher.teacher_image ,
                                (SELECT student_activity_comments.comment_date FROM student_activity_comments WHERE user_type = 'teacher' AND student_activity_comments.activity_id = student_activities.activity_id AND seen_by_parent = 0 ORDER BY comment_date LIMIT 1) AS last_unseen_comment,
                                (SELECT student_activity_comments.comment_id FROM student_activity_comments WHERE user_type = 'teacher' AND student_activity_comments.activity_id = student_activities.activity_id AND seen_by_parent = 0 ORDER BY comment_date LIMIT 1) AS comment_id
                                FROM student_activities 
                                INNER JOIN tbl_teacher ON tbl_teacher.teacher_id = student_activities.teacher_id
                                WHERE student_id = $student_id
                                AND (SELECT student_activity_comments.comment_id FROM student_activity_comments WHERE user_type = 'teacher' 
                                        AND student_activity_comments.activity_id = student_activities.activity_id 
                                        AND seen_by_parent = 0 ORDER BY comment_date LIMIT 1) != ''")->fetchAll();

$notifications3 = $connect->query("SELECT date_sent, tbl_teacher.teacher_name, tbl_teacher.teacher_id, tbl_teacher.teacher_image
                                    FROM `parent_teacher_messages` 
                                    INNER JOIN tbl_teacher ON tbl_teacher.teacher_id = parent_teacher_messages.teacher_id
                                    WHERE student_id = '$student_id' AND user_type = 'teacher' AND seen_by_parent = 0 ORDER BY date_sent DESC LIMIT 1")->fetchAll();

$notifications4 = $connect->query("SELECT *
                                    FROM `live_video` 
                                    WHERE student_id = '$student_id' AND seen_by_parent = 0 ORDER BY ID DESC LIMIT 1")->fetchAll();

$notifications_num = count($notifications) + count($notifications2) + count($notifications3) + count($notifications4);

$student = $connect->query("SELECT student_img, tbl_grade.grade_name FROM tbl_student
                                                INNER JOIN tbl_grade ON tbl_grade.grade_id = tbl_student.student_grade_id
                                                WHERE student_id = $student_id")->fetchAll()[0];

$student_img = '../student_image/'.$student['student_img'];
$student_grade = $student['grade_name'];


?>
<!DOCTYPE html>
<html lang="ar" oncontextmenu="return false;">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo Website_name; ?></title>
<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
</head>
<body dir="rtl">
<script src="../js/jquery.min.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
<script src="../js/main.js?v=<?php echo time(); ?>"></script>
<script src="js/main.js?v=<?php echo time(); ?>"></script>
<nav class="navbar navbar-expand-lg navbar-light bg-dark" id="site-header">
<a href="#" id="openSidebar"><i class="fas fa-bars"></i></a>

<div class="mr-auto"></div>

<?php 
$live = @$connect->query("SELECT * FROM live_video WHERE end_time is Null AND student_id = $student_id")->fetchAll()[0];
if($live) { 
?>
<div class="ml-2">
    <?php if(!isset($_SESSION['live-alert']) || $_SESSION['live-alert'] != $live['ID']) {
        $_SESSION['live-alert'] = $live['ID'];
    ?>
    <script>
        $(document).ready(function() {
            $.alert({
                title:"بث مباشر",
                content:"<?php echo $live['title']; ?>",
                buttons:{
                    "cancel":{
                        text:"إلغاء",
                        action:function(){}
                    },
                    "show":{
                        text:"عرض",
                        btnClass:"btn-danger",
                        action:function(){window.location.href="live-video.php?id=<?php echo $live['ID']; ?>"}
                    }
                }
            })
        })
    </script>
    <?php } ?>
    <a href="live-video.php?id=<?php echo $live['ID']; ?>">
        <img src="../img/live.png" class="blink" alt="بث مباشر" height=50>
    </a>
</div>
<?php } ?>
<div id="notifications">
    <a href="#" class="mr-auto ml-2" id="notifications-icon" onclick="$('#notifications-box').fadeToggle();"><i class="fas fa-bell"></i>
        <span id="notifications-num" <?php echo $notifications_num == 0 ? 'style="display:none"' : ''; ?> ><?php echo $notifications_num; ?></span>
    </a>
    <div id="notifications-box" style="display:none">
        <?php if($notifications_num == 0) {
            echo '<p class="text-center">لا يوجد إشعارات لديك</p>';
        } ?>
        <div id="notification-rows">
            <?php foreach($notifications as $notification) { ?>
            <div class="notification" data-date="<?php echo strtotime($notification['activity_date']); ?>">
                <a href="index.php?activity_id=<?php echo $notification['activity_id']; ?>">
                    <div class="row w-100">
                        <div class="col-3">
                            <img src="../admin/teacher_image/<?php echo $notification['teacher_image']; ?>" alt="Teacher" class="img-thumbnail">
                        </div>
                        <div class="col-9">
                            أضاف المعلم 
                            <?php echo $notification['teacher_name']; ?>
                            نشاط جديد "<?php echo $notification['activity_title']; ?>"
                            <span class="date d-block text-grey-500 mt-2"><?php echo $notification['activity_date']; ?></span>
                        </div>
                    </div>
                </a>
            </div>
            <?php } ?>
            <?php foreach($notifications2 as $notification) { if(!empty($notification['last_unseen_comment'])) { ?>
            <div class="notification" data-date="<?php echo strtotime($notification['last_unseen_comment']); ?>">
                <a href="index.php?activity_id=<?php echo $notification['activity_id']; ?>&comment_id=<?php echo $notification['comment_id']; ?>">
                    <div class="row w-100">
                        <div class="col-3">
                            <img src="../admin/teacher_image/<?php echo $notification['teacher_image']; ?>" alt="Teacher" class="img-thumbnail">
                        </div>
                        <div class="col-9">
                            أضاف المعلم 
                            <?php echo $notification['teacher_name']; ?>
                            تعليقاً جديد على النشاط "<?php echo $notification['activity_title']; ?>"
                            <span class="date d-block text-grey-500 mt-2"><?php echo $notification['last_unseen_comment']; ?></span>
                        </div>
                    </div>
                </a>
            </div>
            <?php }} ?>
            <?php foreach($notifications3 as $notification) { ?>
            <div class="notification" data-date="<?php echo strtotime($notification['date_sent']); ?>">
                <a href="contact-teacher.php">
                    <div class="row w-100">
                        <div class="col-3">
                            <img src="../admin/teacher_image/<?php echo $notification['teacher_image']; ?>" alt="Teacher" class="img-thumbnail">
                        </div>
                        <div class="col-9">
                            أرسل لك المعلم 
                            <?php echo $notification['teacher_name']; ?>
                            رسالة جديدة 
                            <span class="date d-block text-grey-500 mt-2"><?php echo $notification['date_sent']; ?></span>
                        </div>
                    </div>
                </a>
            </div>
            <?php } ?>
            <?php foreach($notifications4 as $notification) { ?>
            <div class="notification" data-date="<?php echo strtotime($notification['start_time']); ?>">
                <a href="live-video.php?id=<?php echo $notification['ID']; ?>">
                    <div class="row w-100">
                        <div class="col-12">
                            <?php 
                            if($notification['user_type'] == 'teacher') {
                                $teacher_name = @$connect->query("SELECT teacher_name FROM tbl_teacher WHERE teacher_id = ".$notification['user_id'])->fetchAll()[0]['teacher_name'];
                                echo 'بدأ المعلم '.$teacher_name.' في  بث فيديو "'.$notification['title'].'"';
                            } elseif($notification['user_type'] == 'specialist') {
                                $specialist_name = @$connect->query("SELECT specialist_name FROM tbl_specialist WHERE specialist_id = ".$notification['user_id'])->fetchAll()[0]['specialist_name'];
                                echo 'بدأ الأخصائي '.$specialist_name.' في  بث فيديو "'.$notification['title'].'"';
                            }
                            ?>
                            <span class="date d-block text-grey-500 mt-2"><?php echo $notification['start_time']; ?></span>
                        </div>
                    </div>
                </a>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<a class="navbar-brand" href="index.php"><img src="../<?php echo "img/".Logo; ?>" alt="logo" height=48></a>
</nav>

<div id="sidebar">
    <a href="#" id="closeSidebar"><i class="fas fa-times"></i></a>

    <div class="row" id="student_card">
        <div class="col-4 text-center"><img src="<?php echo $student_img; ?>" alt="صورة الطالب" id="student_img"></div>
        <div class="col-8 pt-2">
            <h4><?php echo $_SESSION['student_name']; ?></h4>
            <h5><?php echo $student_grade; ?></h5>
            <h6><?php echo $_SESSION['db_ui_name']; ?></h6>
            <h6>وقت الدخول : <span class="date"><?php echo $_SESSION['login_time']; ?></span></h6>
        </div>
    </div>
    
    <ul class="list-unstyled mt-5">
    <li>
        <a href="leaving.php">الإنصراف</a>
    </li>
    <li>
        <a href="index.php">أنشطة الطالب</a>
    </li>
    <li>
       <!-- <a href="schedule.php">جدول الطالب</a>-->
    </li>
    <li>
       <!-- <a href="student-files.php">ملفات الطالب</a>-->
    </li>
    <li>
        <a href="contact-teacher.php">راسل المعلم</a>
    </li>
    <li>
        <a href="foundation_news.php">أخبار المؤسسة</a>
    </li>
    <li>
        <a href="general.php">تعميم</a>
    </li>
      <!--<li>
      <a href="contact_us.php">اتصل بنا</a>
    </li>-->
	<li>
        <a href="logout.php">خروج</a>
    </li>
    <li>
        <a href="tel:<?php echo $phone_num=$connect->query("SELECT * FROM variables WHERE name = 'phone_num'")->fetchAll()[0]['value']; ?>"><i class="fas fa-phone"></i> <?php echo $phone_num; ?></a>
    </li>
    </ul>
</div>