<?php

    if(isset($_GET['show_file']) || isset($_GET['download_file'])) {
        $file_id = isset($_GET['show_file']) ? $_GET['show_file'] : $_GET['download_file'];
        $file_action = isset($_GET['show_file']) ? 'inline' : 'attachment';
        if(!is_numeric($file_id)) {
            die("رقم الملف خاطئ");
        }

        session_start();
        if(!isset($_SESSION['parent'])) {
            die(header("location: ../index.php"));
        }

        $student_id = $_SESSION['parent_student_id'];
        $ajax_dbname = $_SESSION['database'];
        $ajax_db_ui_name = $_SESSION['db_ui_name'];
        
        include "../admin/database_connection.php";

        $file = $connect->query("SELECT * FROM student_documents WHERE student_id = $student_id AND ID = $file_id")->fetchAll();
        if(count($file) == 0) {
            die("رقم الملف خاطئ");
        }

        $file = "../student_documents/".$file[0]['document'];
        $file_type = explode(".", $file);
        $file_type = strtolower($file_type[count($file_type)-1]);

        if (file_exists($file)) {
            $filename = basename($file);
            $file_extension = strtolower(substr(strrchr($file,"."),1));
            $ctype = 'application/octet-stream';
            switch( $file_extension ) {
                case "gif": $ctype="image/gif"; break;
                case "png": $ctype="image/png"; break;
                case "jpeg":
                case "jpg": $ctype="image/jpeg"; break;
                case "avi": $ctype="video/x-msvideo"; break;
                case "mp4": $ctype="video/mp4"; break;
                case "mp3": $ctype="audio/mpeg"; break;
                case "mp3": $ctype="audio/mpeg"; break;
                case "pdf": $ctype="application/pdf"; break;
                default:
            }

            ob_end_clean();
            header('Content-type: ' . $ctype);
            header("Content-Transfer-Encoding: Binary"); 
            header("Content-disposition: $file_action; filename=\"" . basename($file) . "\""); 
            readfile($file); 
            exit;
        } else {
            die("لم يتم العثور علي الملف");
        }

        die();
    }

    include "header.php";
    
    $student_files = $connect->query("SELECT * FROM student_documents WHERE student_id = $student_id ORDER BY date DESC")->fetchAll();
?>

<div class="container bg-white py-5 mt-3">
    
    <h3 class="text-center mb-4">ملفات الطالب (<?php echo count($student_files); ?>)</h3>
    
    <?php if(count($student_files) == 0) {
        echo '<h4 class="text-center">لا يوجد ملفات للطالب</h4>';
    } else { ?>
    <table class="table text-center">
    <thead class="thead-dark">
        <tr>
        <th scope="col">#</th>
        <th scope="col">اسم المستند</th>
        <th scope="col">عرض</th>
        <th scope="col">تحميل</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $i=0;
        foreach($student_files as $file) {
            echo '
            <tr>
            <th scope="row">'.++$i.'</th>
            <td>'.$file['doc_name'].'</td>
            <td><a href="?show_file='.$file['ID'].'" target="_blank" class="btn btn-primary"><i class="far fa-eye"></i> عرض</a></td>
            <td><a href="?download_file='.$file['ID'].'" target="_blank" class="btn btn-success"><i class="fas fa-download"></i> تحميل</a></td>
            </tr>';
        }
        ?>
    </tbody>
    </table>
    <?php } ?>

</div>