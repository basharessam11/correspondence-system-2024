<?php

    include "header.php";

    $contact_us = $connect->query("SELECT value FROM variables WHERE name = 'contact_us'")->fetchAll()[0]['value'];
?>

<div class="container bg-white p-3 my-3">
    <?php echo $contact_us; ?>
</div>