<?php

    include "header.php";

    $general = $connect->query("SELECT value FROM variables WHERE name = 'general'")->fetchAll()[0]['value'];
?>

<div class="container bg-white p-3 my-3">
    <?php echo $general; ?>
</div>