<?php

//logout.php

session_start();

session_destroy();

setcookie('parent', '', 0);
setcookie('database', '', 0);

header('location: ./');

?>