<?php

    include "header.php";

    $teacher = $connect->query("SELECT tbl_teacher.* FROM tbl_student INNER JOIN tbl_teacher ON tbl_student.student_grade_id = tbl_teacher.teacher_grade_id WHERE student_id = $student_id")->fetchAll()[0];
    $teacher_img = '../admin/teacher_image/'.$teacher['teacher_image'].'';
    $staff_name = $connect->query("SELECT GROUP_CONCAT(staff_user_name SEPARATOR ' - ') as staff_members FROM tbl_staff LIMIT 1")->fetchAll()[0]['staff_members'];
    $messages = $connect->query("SELECT parent_teacher_messages.*, tbl_teacher.teacher_name, tbl_teacher.teacher_image 
                                FROM parent_teacher_messages 
                                INNER JOIN tbl_teacher ON tbl_teacher.teacher_id = parent_teacher_messages.teacher_id
                                WHERE student_id = $student_id")->fetchAll();
    $connect->query("UPDATE parent_teacher_messages SET seen_by_parent = 1 WHERE student_id = $student_id");

?>

<style>
    .message {
        padding:1rem 0;
    }
    .message:not(:last-child) {
        border-bottom:1px solid #DDD;
    }
    .message .sender_img {
        width: 100px;
        height: 100px;
        object-fit:cover;
        border-radius:50%;
        border:2px solid #ddd;
    }
    .message-text {
        position: relative;
        padding-bottom: 22px;
    }
    .message-text .date {
        position: absolute;
        bottom: -10px;
        right: 10px;
        direction:ltr;
        color:#888;
        font-size: 0.8rem;
    }
    @media only screen and (max-width:960px) {
        .message .sender_img {
            width: 50px;
            height: 50px;
        }
    }
</style>

<div class="container bg-white py-5 text-right mt-3">
    <div class="row" id="teacher_card">
        <div class="col-3 col-lg-2"><img class="img-fluid" id="teacher_img" src="../admin/teacher_image/<?php echo $teacher['teacher_image'];?>" style="border:2px solid #e9e9e9"></div>
        <div class="col-9 col-lg-10">
            <h5>المعلم : <?php echo $teacher['teacher_name']; ?></h5>    
            <h6>الصف: <?php echo $student_grade; ?></h6>    
            <h6>الإشراف الفني: <?php echo $staff_name; ?></h6>    
        </div>
    </div>
    <hr>
    <div id="messages" class="my-3 px-3">
        <?php echo (count($messages) == 0) ? '<h4 class="my-3 text-center text-dark">لا يوجد رسائل حالياً</h4>' : ''; ?>
        <?php 
        foreach($messages as $message) { 
            
            if($message['user_type'] == 'parent') {
                $sender = '<img class="sender_img" title="ولي الأمر" src="'.$student_img.'">';
            } else {
                $sender = '<img class="sender_img" title="المعلم : '.$message['teacher_name'].'" src="../admin/teacher_image/'.$message['teacher_image'].'">';
            }

            ?>
        <div class="message row">
            <div class="col-3 col-lg-2 text-center"><?php echo $sender; ?></div>
            <div class="col-9 col-lg-10 message-text">
                <p class="text-secondary"><?php echo ($message['user_type'] != 'parent') ? "المعلم : ".$message['teacher_name'] : ''; ?></p>
                <?php echo str_replace("\n", "<br>", $message['message']); ?>
                <span class="date"><?php echo $message['date_sent']; ?></span>
            </div>
        </div>
        <?php } ?>
    </div>
    <hr>
    <div id="message_box" class="pt-3">
        <form action="" method="post" id="send_message">
        <div class="row">
            <div class="col-9 col-lg-10">
                <textarea name="message" class="form-control" rows="4" placeholder="رسالتك..." required></textarea>
            </div>
            <div class="col-3 col-lg-2">
                <button type="submit" class="form-control btn btn-success mt-2"><i class="fas fa-paper-plane"></i> <span class="d-none d-md-inline-block">إرسال</span></button>
            </div>
        </div>
        </form>
    </div>
</div>

<script>
    
    $(document).on("keydown", '[name=message]', function (e){
        if(e.keyCode == 13 && !e.shiftKey){
            $(this).closest("form").trigger("submit");
        }
    });

    $("#send_message").on("submit", function(e){
        e.preventDefault();
        var message = $("[name=message]").val();
        if(message != '')
        $.ajax({
            type:"POST",
            url:"api/send_message.php",
            data:{message:message},
            dataType:"json",
            beforeSend:function() {
                $("[name=message]").attr("readonly", "readonly");
            },
            success:function(data) {
                if(data.success == 'success') {
                    $("[name=message]").removeAttr("readonly").val("");
                    var message_html = '<div class="message row">'+
                                            '<div class="col-2 text-center"><img class="sender_img" title="ولي الأمر" src="<?php echo $student_img;?>"></div>'+
                                            '<div class="col-10 message-text">'+
                                                data.message.replaceAll("\n", "<br>")+
                                                '<span class="date">'+data.date+'</span>'+
                                            '</div>'+
                                        '</div>';

                    $("#messages").append(message_html);
                }
            }
        })
    })
</script>