<?php
    include "header.php";
?>

    <h4 class="text-center my-3 text-light">أنشطة الطالب</h4>

    <div class="container" id="timeline">

        
    </div>

    <script>
        $(document).on("submit", ".send_comment_form", function(e) {
            e.preventDefault();
            if($(this).find("[name=comment]").attr("readonly") == "readonly") {
                return false;
            }
            $(this).find("[name=comment]").attr("readonly", "readonly");

            var activity_id = $(this).data('activity-id');
            var comment = $(this).find("[name=comment]").val();
            var commentTextarea = $(this).find("[name=comment]");

            $.ajax({
                type:"post",
                url:"api/add_comment.php",
                data:{comment:comment, activity_id:activity_id},
                dataType:"json",
                success:function(data) {
                    $(commentTextarea).removeAttr("readonly");

                    if(data.success == 'success') {
                        var date = data.date;
                        var comment = data.comment;
                        var comment_html = '<div class="comment">'+
                                            '<div class="comment-info">'+
                                            '<strong>ولي الأمر</strong>'+
                                            '<p class="date">'+date+'</p>'+
                                            '</div>'+
                                            '<div class="comment-text pr-3">'+
                                            comment.replaceAll("\n", "<br>")+
                                            '</div>'+
                                            '</div>';
                        $("#activity"+activity_id+" .comments").prepend(comment_html);
                        $("#activity"+activity_id+" .comments_num").text($("#activity"+activity_id+" .comment").length);
                        $(commentTextarea).val("");
                    }
                }
            })
        })

        $(document).on("click", ".show-more", function(e){
            e.preventDefault();
            if($(this).data('action') == 'more') {
                $(this).closest('.activity').find(".media-item:not(:first)").show();
                $(this).data('action', 'less');
                $(this).text('عرض اقل');
            } else {
                $(this).closest('.activity').find(".media-item:not(:first)").hide();
                $(this).data('action', 'more');
                $(this).text('عرض المزيد');
            }
        })


        $(document).on("click", ".add-like", function() {
                var like = ($(this).hasClass('liked')) ? 0 : 1;
                var activity_id = $(this).data('activity-id');
                var button = $(this)[0];
                $.ajax({
                    type:"POST",
                    url:"api/activity_like.php",
                    data:{like:like, activity_id:activity_id},
                    dataType:"json",
                    success:function(data) {
                        if(data.success == 'success') {
                            if($(button).hasClass('liked'))
                                $(button).removeClass('liked').html('<i class="far fa-thumbs-up"></i> إعجاب');
                            else
                                $(button).addClass('liked').html('<i class="fas fa-thumbs-up"></i> إلغاء');
                        }
                    }
                })
            })

        $(document).on("click", ".add-comment", function() {
                $(document).blur();
                $(this).closest(".activity").find("[name=comment]").focus();
            })

        $(document).on("keydown", '[name=comment]', function (e){
                if(e.keyCode == 13 && !e.shiftKey){
                    $(this).closest("form").trigger("submit");
                }
            });


        $(document).ready(function () {
            loadActivities();

            window.onscroll = function(ev) {
                if (document.body.offsetHeight - (window.innerHeight + window.scrollY) < 200) {
                    loadActivities();
                }
            };
        })

        var loading = false;
        var activities_end = false;
        var activity_id = <?php echo (@is_numeric($_GET['activity_id'])) ? $_GET['activity_id'] : 'false'; ?>;
        var comment_id = <?php echo (@is_numeric($_GET['comment_id'])) ? $_GET['comment_id'] : 'false'; ?>;
        function loadActivities() {
            if(!loading && !activities_end)
            $.ajax({
                type:"POST",
                url:"api/load_activities.php",
                data:{loaded:$("#timeline .activity").length, activity_id:activity_id},
                beforeSend:function() {
                    loading = true;
                    lastIndex = $("#timeline .activity").length;
                },
                success:function(data) {
                    loading = false;
                    if(data.includes("</")) {
                        $("#timeline").append(data);

                        if(comment_id != false)
                            $([document.documentElement, document.body]).animate({
                                scrollTop: $("#comment"+comment_id).offset().top
                            }, 500);

                        $(".activity").not(".activity:lt("+lastIndex+")").each(function () {
                            $(this).find(".media-item:not(:first)").hide();
                        })
                    } else {
                        activities_end = true;
                    }
                }
            })
        }
    </script>
</body>
</html>
