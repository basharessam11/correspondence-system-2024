<?php



    include "header.php";

?>

<style>

    @media (max-width:1200px) {

        iframe{

            height:400px

        }   

    }

    @media (max-width:900px) {

        iframe{

            height:200px

        }   

    }

</style>

<div class="container my-5 p-2 bg-light text-center">

    

<?php

    if(isset($_GET['id']) && is_numeric($_GET['id'])) {

        $live = $connect->query("SELECT live_video.*, tbl_teacher.teacher_name, tbl_specialist.specialist_name FROM live_video 

                                LEFT JOIN tbl_teacher ON tbl_teacher.teacher_id = live_video.user_id

                                LEFT JOIN tbl_specialist ON tbl_specialist.specialist_id = live_video.user_id

                                WHERE student_id = '$student_id' AND live_video.ID = ".$_GET['id'])->fetchAll()[0];



        if($live) { 

            echo "<h4 class='my-3'>".$live['title']."</h4>";

            echo ($live['user_type'] == 'teacher') ? "<p>المعلم: ".$live['teacher_name']."</p>" : "<p>الأخصائي: ".$live['specialist_name']."</p>";

            echo "<span class='date' dir=ltr>".$live['start_time']."</span>";

            if(strpos($live['url'], "vimeo") !== FALSE) {

                $vimeo_id = explode("vimeo.com/", $live['url']);

                $vimeo_id = $vimeo_id[count($vimeo_id)-1];

                echo "<iframe src='https://player.vimeo.com/video/$vimeo_id?modestbranding=1&autoplay=1&mute=1' width=100% height=600 frameborder=0 allowfullscreen class='mx-auto'></iframe>";

            } elseif( ( strpos($live['url'], "youtube") !== FALSE || strpos($live['url'], "youtu.be") !== FALSE) 

                    ) {

                if(preg_match('![?&]{1}v=([^&]+)!', $live['url'] . '&', $m)) {

                    $youtube_id = $m[1];

                } else {

                    $youtube_id = explode("/", $live['url']);

                    $youtube_id = $youtube_id[count($youtube_id)-1];

                }

                echo "<iframe src='https://www.youtube.com/embed/$youtube_id' width=100% height=600 frameborder=0 allowfullscreen class='mx-auto'></iframe>";

            }



            ?>

            <div class="row mt-3">

                <div class="col-6">

                    <button class="add-like w-100<?php echo ($live['parent_liked'] == 1) ? ' liked' : ''; ?>" data-live-id="<?php echo $live['ID'] ?>">

                        

                        <?php echo ($live['parent_liked'] == 1) ? ' <i class="fas fa-thumbs-up"></i> إلغاء' : '<i class="far fa-thumbs-up"></i> إعجاب'; ?>

                    </button>

                </div>

                <div class="col-6">

                    <button class="add-comment w-100" data-live-id="<?php echo $live['ID'] ?>"><i class="far fa-comment-dots"></i> تعليق</button>

                </div>

            </div>

            <div class="mt-3">

                <?php 

                $comments = $connect->query("SELECT live_video_comments.*, tbl_teacher.teacher_name, tbl_specialist.specialist_name 

                                        FROM live_video_comments 

                                        LEFT JOIN tbl_teacher ON tbl_teacher.teacher_id = live_video_comments.user_id

                                        LEFT JOIN tbl_specialist ON tbl_specialist.specialist_id = live_video_comments.user_id

                                        WHERE live_id = ".$live['ID']." ORDER BY comment_date DESC")->fetchAll();

                ?>

                <legend>التعليقات (<span class="comments_num"><?php echo count($comments) ?></span>)</legend>

                <form class="type-box row pb-2 send_comment_form" data-live-id="<?php echo $live['ID'] ?>" method="post">

                    <div class="col-12 col-lg-10">

                        <textarea name="comment" class="form-control" rows="3" placeholder="تعليقك..."></textarea>

                    </div>

                    <div class="col-12 col-lg-2 text-center">

                        <button type="submit" class="form-control btn btn-success mt-2 send_comment"><i class="fas fa-paper-plane"></i></button>

                    </div>

                </form>

                <div class="comments">

                    <?php

                    foreach ($comments as $comment) { 

                        

                        if($comment['user_type'] == 'specialist') {

                            $user = 'المتخصص: '. $comment['specialist_name'];

                        } elseif ($comment['user_type'] == 'teacher') {

                            $user = 'المعلم: '. $comment['teacher_name'];

                        } elseif ($comment['user_type'] == 'parent') {

                            $user = 'أنت: ';

                        } else {

                            $user = '';

                        }

                    ?>

                    <div class="comment" id="comment<?php echo $comment['ID']; ?>">

                        <div class="comment-info">

                            <strong><?php echo $user; ?></strong>

                            <p class="date"><?php echo $comment['comment_date']; ?></p>

                        </div>

                        <div class="comment-text pr-3">

                            <?php echo str_replace("\n", "<br>", $comment['comment']); ?>

                        </div>

                    </div>

                    <?php } ?>

                    

                </div>

            </div>

            <?php



            $connect->query("UPDATE live_video SET seen_by_parent = 1 WHERE live_video.ID = ".$_GET['id']);

        }

    } 



?>



</div>



<script>

    

    $(document).on("submit", ".send_comment_form", function(e) {

        e.preventDefault();

        if($(this).find("[name=comment]").attr("readonly") == "readonly") {

            return false;

        }

        $(this).find("[name=comment]").attr("readonly", "readonly");



        var live_id = $(this).data('live-id');

        var comment = $(this).find("[name=comment]").val();

        var commentTextarea = $(this).find("[name=comment]");



        $.ajax({

            type:"post",

            url:"api/live_api.php",

            data:{comment:comment, live_id:live_id},

            dataType:"json",

            success:function(data) {

                $(commentTextarea).removeAttr("readonly");



                if(data.success == 'success') {

                    var date = data.date;

                    var comment = data.comment;

                    var comment_html = '<div class="comment">'+

                                        '<div class="comment-info">'+

                                        '<strong>ولي الأمر</strong>'+

                                        '<p class="date">'+date+'</p>'+

                                        '</div>'+

                                        '<div class="comment-text pr-3">'+

                                        comment.replaceAll("\n", "<br>")+

                                        '</div>'+

                                        '</div>';

                    $(".comments").prepend(comment_html);

                    $(".comments_num").text($(".comment").length);

                    $(commentTextarea).val("");

                }

            }

        })

    })



    $(document).on("click", ".add-like", function() {

        var like = ($(this).hasClass('liked')) ? 0 : 1;

        var live_id = $(this).data('live-id');

        var button = $(this)[0];

        $.ajax({

            type:"POST",

            url:"api/live_api.php",

            data:{like:like, live_id:live_id},

            dataType:"json",

            success:function(data) {

                if(data.success == 'success') {

                    if($(button).hasClass('liked'))

                        $(button).removeClass('liked').html('<i class="far fa-thumbs-up"></i> إعجاب');

                    else

                        $(button).addClass('liked').html('<i class="fas fa-thumbs-up"></i> إلغاء');

                }

            }

        })

    })

    $(document).on("click", ".add-comment", function() {

        $(document).blur();

        $("[name=comment]").focus();

    })



    $(document).on("keydown", '[name=comment]', function (e){

        if(e.keyCode == 13 && !e.shiftKey){

            $(this).closest("form").trigger("submit");

        }

    });

</script>