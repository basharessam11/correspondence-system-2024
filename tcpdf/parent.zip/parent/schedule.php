<?php

    use \ConvertApi\ConvertApi;

    if(isset($_GET['show']) || isset($_GET['download'])) {
        session_start();
        if(!isset($_SESSION['parent'])) {
            die(header("location:index.php"));
        }

        include "../admin/database_connection.php";
        include "../vendor/autoload.php";

        $student_id = $_SESSION['parent_student_id'];

        $student_name = @$connect->query("SELECT student_name FROM tbl_student WHERE student_id = $student_id")->fetchAll()[0]['student_name'];

        $grade = $connect->query("SELECT tbl_grade.grade_name, tbl_grade.grade_id FROM tbl_student
                            INNER JOIN tbl_grade ON tbl_grade.grade_id = tbl_student.student_grade_id 
                            WHERE student_id = $student_id")->fetchAll()[0];
        $grade_id = $grade['grade_id'];
        $grade_name = $grade['grade_name'];

        $activity_times = $connect->query("SELECT ID, activity_class, TIME_FORMAT(activity_from, '%H:%i') as activity_from, 
                                        TIME_FORMAT(activity_to, '%H:%i') as activity_to FROM `activity_times`;")->fetchAll();

        $activities_schedule = $connect->query("SELECT activities_schedule.*, activities.name as activity_name FROM activities_schedule 
                                                INNER JOIN activities ON activities.ID = activities_schedule.activity_id
                                                WHERE student_id = $student_id")->fetchAll();


        $phpWord = new \PhpOffice\PhpWord\PhpWord();
        $filename = '../student-schedule.docx';
        $document = $phpWord->loadTemplate($filename);
        $document->setValue('SCHOOL_YEAR', $_SESSION['db_ui_name']);
        $document->setValue('GRADE_NAME', $grade_name);
        $document->setValue('STUDENT_NAME', $student_name);
        $i = 0;
        foreach($activity_times as $activity_time) {
            $document->setValue('c'.$i.'f', $activity_time['activity_from']);
            $document->setValue('c'.$i.'t', $activity_time['activity_to']);
            $i++;
        }
        foreach($activities_schedule as $activity) {
            $d = $activity['day'];
            $c = $activity['class'];
            $document->setValue('d'.$d.'_c'.$c, $activity['activity_name']);
        }
        $document->saveAs('../student_schedule/student_'.$student_id.'_schedule.docx');

        ConvertApi::setApiSecret(Convert_Api_Secret);
        $result = ConvertApi::convert('pdf', [
                'File' => '../student_schedule/student_'.$student_id.'_schedule.docx',
            ], 'doc'
        );
        $result->saveFiles('../student_schedule/student_'.$student_id.'_schedule.pdf');
        unlink('../student_schedule/student_'.$student_id.'_schedule.docx');

        if(isset($_GET['download'])) {
            header("Content-type: application/pdf");
            header("Content-Disposition:attachment;filename=جدول الطالب - ".$student_name.".pdf");
            readfile("../student_schedule/student_".$student_id."_schedule.pdf");
        } else {
            echo "<title>جدول الطالب - ".$student_name."</title><style>body{margin:0;overflow:hidden}</style><iframe src=\"../student_schedule/student_".$student_id."_schedule.pdf\" width=\"100%\" style=\"height:100%\"></iframe>";
        }
        die();
    }

    if(@is_numeric($_POST['get_student_schedule'])) {
        session_start();
        $result = array();
        if(!isset($_SESSION['admin_id'])) {
            $result['error'] = 'Not Logged in';
        }

        include "../admin/database_connection.php";
        include "../vendor/autoload.php";

        $student_id = $_POST['get_student_schedule'];
        $result['activities_schedule'] = $connect->query("SELECT activities_schedule.*, activities.name AS activity_name FROM activities_schedule 
                                                INNER JOIN activities ON activities.ID = activities_schedule.activity_id
                                                WHERE student_id = $student_id")->fetchAll();
        $result['success'] = 'success';
        echo json_encode($result);
        die();
    }

    include "header.php";
    
    $activities = $connect->query("SELECT * FROM activities ORDER BY name ASC")->fetchAll();
    $activity_times = $connect->query("SELECT ID, activity_class, TIME_FORMAT(activity_from, '%H:%i') as activity_from, TIME_FORMAT(activity_to, '%H:%i') as activity_to FROM `activity_times`;")->fetchAll();

?>
<style>
    th, td {
        padding:10px 5px;
    }
    .input-row {
        width:100%;
        font-size:1.2rem;
        border: 0;
        border-bottom:1px solid #888;
        background: #f5f5f5;
        text-align:right;
        direction:rtl;
    }
    @media only screen and  (max-width:960px){
        form {
            overflow-x: scroll;
        }
    }
</style>

<div class="container text-right bg-white py-5 mt-3" style="direction:rtl">
    <h3 class="text-center mb-4">جدول الطالب</h3>
    <form action="" method="POST">
        
        <table class="table table-bordered">
        
            <thead class="thead-dark">
            <tr>
                <th rowspan=3 >الحصص</th>
                <th rowspan=2 >التوقيت</th>
                <th colspan=5 >أيام الأسبوع</th>
            </tr>
            <tr>
                <th>الأحد</th>
                <th>الاثنين</th>
                <th>الثلاثاء</th>
                <th>الأربعاء</th>
                <th>الخميس</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td></td>
                <td><?php echo $activity_times[0]['activity_from'];?> إلى <?php echo $activity_times[0]['activity_to'];?></td>
                <td colspan=5 class="text-center"><?php echo $activity_times[0]['activity_class'];?></td>
            </tr>
            <?php 
            for($i = 1; $i <= 9; $i++) { // 9 classes 
                echo '<td>'.$activity_times[$i]['activity_class'].'</td>
                    <td>'.$activity_times[$i]['activity_from'].' إلى '.$activity_times[$i]['activity_to'].'</td>
                    <td class="data-flield" id="d1_c'.$i.'"></td>
                    <td class="data-flield" id="d2_c'.$i.'"></td>
                    <td class="data-flield" id="d3_c'.$i.'"></td>
                    <td class="data-flield" id="d4_c'.$i.'"></td>
                    <td class="data-flield" id="d5_c'.$i.'"></td>
                    <tr>';
            } 
            ?>
            </tbody>
        </table>
        <div class="text-center p-3" style="display:none" id="buttons">
            <a href="?show" id="show_btn" target="_blank" class="btn btn-warning" >طباعة</a>
            <a href="?download" id="download_btn" target="_blank" class="btn btn-primary" >تحميل</a>
        </div>
    </form>
</div>

<script>
    $(document).ready(function() {
        
        var student_id = <?php echo $_SESSION['parent_student_id'];?> ;
        $("form #buttons").hide();
        $("form table").hide();
        $(".data-flield").text('');
        if(!isNaN(student_id)) {
            $.ajax({
                type:"POST",
                url:"schedule.php",
                data:{get_student_schedule:student_id},
                dataType:"json",
                success:function(r) {
                    if(r.success == 'success') {
                        var activities_schedule = r.activities_schedule;
                        for(var i = 0; i < r.activities_schedule.length; i++) {
                            var day = activities_schedule[i]['day'];
                            var clas = activities_schedule[i]['class'];
                            var activity_name = activities_schedule[i]['activity_name'];
                            $("#d"+day+"_c"+clas).text(activity_name);
                        }
                        $("#download_btn").attr("href", "?download="+student_id);
                        $("#show_btn").attr("href", "?show="+student_id);
                        $("form #buttons").fadeIn(500);
                        $("form table").fadeIn(500);
                    }
                }
            })
        }
    })
</script>