#!/bin/bash
# run_within_time_window.sh

current_hour=$(date +'%H' | sed 's/^0*//')

# Check if the current hour is between 09 (inclusive) and 16 (exclusive)
if [[ $current_hour -ge 9 && $current_hour -lt 17 ]]; then
  for i in {1..5}
  do
    wget -o /dev/null https://dzrt.host/bot/check.php
    wget -o /dev/null https://dzrt.host/bot/check2.php
    sleep 10
  done
fi

