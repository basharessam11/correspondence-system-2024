#!/bin/bash

current_hour=$(date +'%H')

# Check if the current hour is not between 09 and 16
if [[ $current_hour -lt 09 || $current_hour -ge 16 ]]; then
  wget -o /dev/null https://dzrt.host/bot/check.php
fi
