<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>بوت تنبيهات دزرت</title>
    <meta name="description" content="بوت يساعدك في تتبع توافر منتجات DZRT" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200..1000&display=swap" rel="stylesheet">
    <style>
    .center {
        font-family: 'Cairo';
        text-align: center;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }
    </style>
</head>
<body>
    
        <div class="center">
            <h1>
                إشترك في بوت تنبيهات دزيت
            <br>
            <a href="https://t.me/DZRT_Vipp_bot" style="text-decoration: none;">DZRT VIP Bot</a>

            </h1>        
        </div>
    
</body>
</html>