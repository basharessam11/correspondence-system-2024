<?php

require_once '../config.php';

$users = mysqli_query($conn, "SELECT * FROM `data`");

$products = [];
$p_name = [
    'ايسي رش',
    'منت فيوجن',
    'جاردن منت',
    'هايلاند بيريز',
    'إيدجي منت',
    'سي سايد فروست',
    'سبايسي زيست',
    'بيربل مست'
];

// Site Is Down
if (mysqli_query($conn, "SELECT * FROM `options` WHERE `name` = 'site_down_'")->fetch_assoc()['noti'] == '0') {

    // Send All Is Avaliable
    foreach ($users as $user) {

        if ($user['days'] > 0) {

            // Delete Old Message
            bot('deleteMessage', [
                'chat_id' => $chat_id2,
                'message_id' => $message2,
            ]);

            // Send Message
            bot('sendMessage', [
                'chat_id' => $user['user_id'],
                'parse_mode' => 'markdown',
                'text' => '* جاري تحديث موقع دزرت الأن *',
                'reply_markup' => json_encode([
                    "inline_keyboard" => [
                        [
                            [
                                "text" => "القائمة الرئسية ↩️",
                                "callback_data" => "back"
                            ]
                        ]
                    ]
                ])
            ]);
        }
    }
    mysqli_query($conn, "UPDATE `options` set `noti` = '1' WHERE `name` = 'site_down_'");
} else {

    $icy = explode('</span>', explode('title="&#x0627;&#x0644;&#x062A;&#x0648;&#x0641;&#x0631;"> <span>', file_get_contents('https://www.dzrt.com/ar/icy-rush.html'))[1])[0];
    if ($icy == 'متوفر') {
        $products['ايسي رش'] = 1;
    }

    $mint = explode('</span>', explode('title="&#x0627;&#x0644;&#x062A;&#x0648;&#x0641;&#x0631;"> <span>', file_get_contents('https://www.dzrt.com/ar/mint-fusion.html'))[1])[0];
    if ($mint == 'متوفر') {
        $products['منت فيوجن'] = 1;
    }

    $garden = explode('</span>', explode('title="&#x0627;&#x0644;&#x062A;&#x0648;&#x0641;&#x0631;"> <span>', file_get_contents('https://www.dzrt.com/ar/garden-mint.html'))[1])[0];
    if ($garden == 'متوفر') {
        $products['جاردن منت'] = 1;
    }

    $high = explode('</span>', explode('title="&#x0627;&#x0644;&#x062A;&#x0648;&#x0641;&#x0631;"> <span>', file_get_contents('https://www.dzrt.com/ar/highland-berries.html'))[1])[0];
    if ($high == 'متوفر') {
        $products['هايلاند بيريز'] = 1;
    }

    $edgy = explode('</span>', explode('title="&#x0627;&#x0644;&#x062A;&#x0648;&#x0641;&#x0631;"> <span>', file_get_contents('https://www.dzrt.com/ar/edgy-mint.html'))[1])[0];
    if ($edgy == 'متوفر') {
        $products['إيدجي منت'] = 1;
    }

    $sea = explode('</span>', explode('title="&#x0627;&#x0644;&#x062A;&#x0648;&#x0641;&#x0631;"> <span>', file_get_contents('https://www.dzrt.com/ar/seaside-frost.html'))[1])[0];
    if ($sea == 'متوفر') {
        $products['سي سايد فروست'] = 1;
    }

    $zest = explode('</span>', explode('title="&#x0627;&#x0644;&#x062A;&#x0648;&#x0641;&#x0631;"> <span>', file_get_contents('https://www.dzrt.com/ar/spicy-zest.html'))[1])[0];
    if ($zest == 'متوفر') {
        $products['سبايسي زيست'] = 1;
    }

    $mist = explode('</span>', explode('title="&#x0627;&#x0644;&#x062A;&#x0648;&#x0641;&#x0631;"> <span>', file_get_contents('https://www.dzrt.com/ar/purple-mist.html'))[1])[0];
    if ($mist == 'متوفر') {
        $products['بيربل مست'] = 1;
    }
}

// Send Functions
if (!empty($products)) {
    require_once 'main.php';
}

?>