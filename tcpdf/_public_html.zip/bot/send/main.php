<?php

foreach ($products as $key => $value) {

    $p_id = array_search($key, $p_name) + 1;

    $rand = rand(1, 99999);
    $lastNoti = mysqli_query($conn, "SELECT * FROM `options` WHERE `name` = '$p_id'")->fetch_assoc()['updated_at'];
    $newDate = date("H:i:s", strtotime($lastNoti));

    $start = strtotime($newDate);
    $end = strtotime(date('H:i:s'));

    $mins = (int) (($end - $start) / 60);

    if (abs($mins) >= 5) {
        foreach ($users as $user) {
            if ($user['days'] > 0) {
                if ($user['p1'] == 1 && $p_id == 1) {
                    bot('sendPhoto', [
                        'chat_id' => $user['user_id'],
                        'parse_mode' => 'markdown',
                        'photo' => 'https://tqaer.com/data/1.png',
                        'caption' => '*ايسي رش* أصبح متوفر الأن',
                        'reply_markup' => json_encode([
                            "inline_keyboard" => [
                                [
                                    [
                                        "text" => "عرض صفحة المنتج",
                                        "url" => "https://www.dzrt.com/ar/icy-rush.html"
                                    ],
                                    [
                                        "text" => "القائمة الرئيسية ↩️",
                                        "callback_data" => "back"
                                    ],
                                ]
                            ]
                        ])
                    ]);
                }

                if ($user['p2'] == 1 && $p_id == 2) {
                    bot('sendPhoto', [
                        'chat_id' => $user['user_id'],
                        'parse_mode' => 'markdown',
                        'photo' => 'https://tqaer.com/data/2.png',
                        'caption' => '* منت فيوجن* أصبح متوفر الأن',
                        'reply_markup' => json_encode([
                            "inline_keyboard" => [
                                [
                                    [
                                        "text" => "عرض صفحة المنتج",
                                        "url" => "https://www.dzrt.com/ar/mint-fusion.html"
                                    ],
                                    [
                                        "text" => "القائمة الرئيسية ↩️",
                                        "callback_data" => "back"
                                    ],
                                ]
                            ]
                        ])
                    ]);
                }

                if ($user['p3'] == 1 && $p_id == 3) {
                    bot('sendPhoto', [
                        'chat_id' => $user['user_id'],
                        'parse_mode' => 'markdown',
                        'photo' => 'https://tqaer.com/data/3.png',
                        'caption' => '* جاردن منت* أصبح متوفر الأن',
                        'reply_markup' => json_encode([
                            "inline_keyboard" => [
                                [
                                    [
                                        "text" => "عرض صفحة المنتج",
                                        "url" => "https://www.dzrt.com/ar/garden-mint.html"
                                    ],
                                    [
                                        "text" => "القائمة الرئيسية ↩️",
                                        "callback_data" => "back"
                                    ],
                                ]
                            ]
                        ])
                    ]);
                }

                if ($user['p4'] == 1 && $p_id == 4) {
                    bot('sendPhoto', [
                        'chat_id' => $user['user_id'],
                        'parse_mode' => 'markdown',
                        'photo' => 'https://tqaer.com/data/4.png',
                        'caption' => '* هايلاند بيريز* أصبح متوفر الأن',
                        'reply_markup' => json_encode([
                            "inline_keyboard" => [
                                [
                                    [
                                        "text" => "عرض صفحة المنتج",
                                        "url" => "https://www.dzrt.com/ar/highland-berries.html"
                                    ],
                                    [
                                        "text" => "القائمة الرئيسية ↩️",
                                        "callback_data" => "back"
                                    ],
                                ]
                            ]
                        ])
                    ]);
                }

                if ($user['p5'] == 1 && $p_id == 5) {
                    bot('sendPhoto', [
                        'chat_id' => $user['user_id'],
                        'parse_mode' => 'markdown',
                        'photo' => 'https://tqaer.com/data/5.png',
                        'caption' => '* إيدجي منت* أصبح متوفر الأن',
                        'reply_markup' => json_encode([
                            "inline_keyboard" => [
                                [
                                    [
                                        "text" => "عرض صفحة المنتج",
                                        "url" => "https://www.dzrt.com/ar/edgy-mint.html"
                                    ],
                                    [
                                        "text" => "القائمة الرئيسية ↩️",
                                        "callback_data" => "back"
                                    ],
                                ]
                            ]
                        ])
                    ]);
                }

                if ($user['p6'] == 1 && $p_id == 6) {
                    bot('sendPhoto', [
                        'chat_id' => $user['user_id'],
                        'parse_mode' => 'markdown',
                        'photo' => 'https://tqaer.com/data/6.png',
                        'caption' => '* سي سايد فروست* أصبح متوفر الأن',
                        'reply_markup' => json_encode([
                            "inline_keyboard" => [
                                [
                                    [
                                        "text" => "عرض صفحة المنتج",
                                        "url" => "https://www.dzrt.com/ar/seaside-frost.html"
                                    ],
                                    [
                                        "text" => "القائمة الرئيسية ↩️",
                                        "callback_data" => "back"
                                    ],
                                ]
                            ]
                        ])
                    ]);
                }

                if ($user['p7'] == 1 && $p_id == 7) {
                    bot('sendPhoto', [
                        'chat_id' => $user['user_id'],
                        'parse_mode' => 'markdown',
                        'photo' => 'https://tqaer.com/data/7.png',
                        'caption' => '* سبايسي زيست* أصبح متوفر الأن',
                        'reply_markup' => json_encode([
                            "inline_keyboard" => [
                                [
                                    [
                                        "text" => "عرض صفحة المنتج",
                                        "url" => "https://www.dzrt.com/ar/spicy-zest.html"
                                    ],
                                    [
                                        "text" => "القائمة الرئيسية ↩️",
                                        "callback_data" => "back"
                                    ],
                                ]
                            ]
                        ])
                    ]);
                }

                if ($user['p8'] == 1 && $p_id == 8) {
                    bot('sendPhoto', [
                        'chat_id' => $user['user_id'],
                        'parse_mode' => 'markdown',
                        'photo' => 'https://tqaer.com/data/8.png',
                        'caption' => '* بيربل مست* أصبح متوفر الأن',
                        'reply_markup' => json_encode([
                            "inline_keyboard" => [
                                [
                                    [
                                        "text" => "عرض صفحة المنتج",
                                        "url" => "https://www.dzrt.com/ar/purple-mist.html"
                                    ],
                                    [
                                        "text" => "القائمة الرئيسية ↩️",
                                        "callback_data" => "back"
                                    ],
                                ]
                            ]
                        ])
                    ]);
                }
            } else {

                // Check If Resubscribe Send
                if ($user['notification_end_package'] == 0) {

                    $get_last_activate_code = mysqli_query($conn, "SELECT * FROM `codes` WHERE `user_id` = '{$user['user_id']}' AND `is_used` = 1 ORDER BY `created_at` DESC LIMIT 1")->fetch_assoc();

                    bot('sendText', [
                        'chat_id' => $user['user_id'],
                        'parse_mode' => 'markdown',
                        'text' => '
حبينا نبلغك تم انتهى الاشتراك لديك     
رقم الفاتورة : ' . str_replace('SUB', '', $get_last_activate_code['code']) . '     
رقم العميل : ' . $user['user_id'] . '     
تاريخ الاشتراك : ' . date('d-m-Y', $get_last_activate_code['updated_at']) . '     
تاريخ الإنتهاء : ' . date('d-m-Y', strtotime($get_last_activate_code['updated_at'], '+' . $$get_last_activate_code['days'] . 'days')) . '     
مدة الاشتراك : ' . $get_last_activate_code['days'] . ' يوماً    
سعدنا فيك تقدر تشترك مره ثانية اضغط 
/start 
ومن ثم حالة الاشتراك
                        ',
                        'reply_markup' => $main_menu3
                    ]);

                    mysqli_query($conn, "UPDATE `data` SET `notification_end_package` = 1 WHERE `user_id` = '{$user['user_id']}'");
                }
            }
        }

        // Update Last Message
        mysqli_query($conn, "UPDATE `options` SET `noti` = '$rand'  WHERE `name` = '$p_id'");

    }

}

?>