<?php

$DZRT_SITE = file_get_contents('https://www.dzrt.com/ar/our-products.html');
$ALL_PRODUCTS = explode('<strong class="product name product-item-name">', $DZRT_SITE);

// Check Site Is Alive Or Not
if ($DZRT_SITE) {
    header('Location: send/final_send.php');
} else {
    header('Location: send/0.php');
}

?>