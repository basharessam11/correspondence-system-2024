-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2024 at 02:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dzrtbot`
--

-- --------------------------------------------------------

--
-- Table structure for table `codes`
--

CREATE TABLE `codes` (
  `id` int(10) NOT NULL,
  `code` varchar(20) NOT NULL,
  `days` int(10) NOT NULL,
  `is_used` int(1) NOT NULL DEFAULT 0,
  `user_id` varchar(20) DEFAULT NULL,
  `created_at` date NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(10) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `p1` int(1) NOT NULL DEFAULT 1,
  `p2` int(1) NOT NULL DEFAULT 1,
  `p3` int(1) NOT NULL DEFAULT 1,
  `p4` int(1) NOT NULL DEFAULT 1,
  `p5` int(1) NOT NULL DEFAULT 1,
  `p6` int(1) NOT NULL DEFAULT 1,
  `p7` int(1) NOT NULL DEFAULT 1,
  `p8` int(1) NOT NULL DEFAULT 1,
  `3mg` int(1) NOT NULL DEFAULT 1,
  `6mg` int(1) NOT NULL DEFAULT 1,
  `10mg` int(1) NOT NULL DEFAULT 1,
  `have_trial` int(1) NOT NULL DEFAULT 1,
  `days` int(10) NOT NULL DEFAULT 0,
  `notification_end_package` int(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `user_id`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`, `p7`, `p8`, `3mg`, `6mg`, `10mg`, `have_trial`, `days`, `notification_end_package`, `created_at`) VALUES
(15, '000000000', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 149, 1, '2024-06-03 19:29:43');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `noti` varchar(10) NOT NULL DEFAULT '0',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `name`, `noti`, `updated_at`) VALUES
(1, '1', '97943', '2024-04-23 21:43:41'),
(2, '2', '84250', '2024-04-28 19:54:16'),
(3, '3', '83833', '2024-04-24 18:17:04'),
(4, '4', '96660', '2024-04-26 20:26:08'),
(5, '5', '31873', '2024-05-08 22:57:32'),
(6, '6', '76592', '2024-05-09 19:50:43'),
(7, '7', '74784', '2024-05-16 20:15:53'),
(8, '8', '90881', '2024-04-24 20:22:03'),
(9, 'admin', '365', '2024-04-22 11:00:04'),
(10, 'site_down_', '0', '2024-05-23 00:00:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `codes`
--
ALTER TABLE `codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `codes`
--
ALTER TABLE `codes`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
