<?php 

$user_data = mysqli_query($conn, "SELECT * FROM `data` WHERE `user_id` = '$chat_id2'")->fetch_assoc();

if ($user_data['days'] > 0) {

    $code_data = mysqli_query($conn, "SELECT * FROM `codes` WHERE `user_id` = '$chat_id2' AND `is_used` = 1 ORDER BY `updated_at` DESC")->fetch_assoc();

    // User HAve Days Left
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*عدد الأيام المتبقية لديك في الإشتراك : ' . $user_data['days'] . ' يوم*
*رقم العميل : ' . $chat_id2 . '*        
*رقم الإشتراك : ' . str_replace('SUB', '', $code_data['code']) . '*',
        'reply_markup' => $main_menu2
    ]);
} else {
    // No Days Left
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*ليس لديك إشتراك*
        ',
        'reply_markup' => $main_menu3
    ]);
}

?>