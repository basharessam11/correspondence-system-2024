<?php

$conn = mysqli_connect('localhost', 'u789754942_bot', 'Osamah!@#2004', 'u789754942_bot');

// Site Down
mysqli_query($conn, "UPDATE `options` set `noti` = '0' WHERE `name` = 'site_down_'");

$bot_users = mysqli_query($conn, "SELECT * FROM `data`");

while ($user = $bot_users->fetch_assoc()) {
    
    if ($user['days'] > 0) {
        $new_days = $user['days'] - 1;
        mysqli_query($conn, "UPDATE `data` SET `days` = '$new_days' WHERE `user_id` = '{$user['user_id']}'");
    }

    mysqli_query($conn, "UPDATE `data` SET `notification_end_package` = 0 WHERE `user_id` = '{$user['user_id']}'");

}

?>