<?php

    // USer Data
    $user_data = mysqli_query($conn, "SELECT * FROM `data` WHERE `user_id` = '$chat_id2'")->fetch_assoc();

    // Check If User Have Trial
    if ($user_data['have_trial'] == 1) {
        // Have Trials
        bot('sendMessage', [
            'chat_id' => $chat_id2,
            'parse_mode' => 'markdown',
            'text' => '
مرحباً بك لقد تم تفعيل إشتراكك لمدة يوم واحد 
ينتهي الإشتراك يوم ' . date("Y-m-d",strtotime("tomorrow")) . '
            ',
            'reply_markup' => $main_menu2
        ]);

        // Add 1 Day To The User
        $new_days = $user_data['days'] + 1;
        mysqli_query($conn, "UPDATE `data` SET `days` = '$new_days' WHERE `user_id` = '$chat_id2'");
        
        // Remove The Right Of Asking For Trial
        mysqli_query($conn, "UPDATE `data` SET `have_trial` = 0 WHERE `user_id` = '$chat_id2'");
    } else {
        // Dont Have Trials
        bot('sendMessage', [
            'chat_id' => $chat_id2,
            'parse_mode' => 'markdown',
            'text' => '
*لقد حصلت بالفعل على تجربتك المجانية يمكنك طلب إشتراك عن طريق المتجر*
            ',
            'reply_markup' => $main_menu2
        ]);
    }
    

?>