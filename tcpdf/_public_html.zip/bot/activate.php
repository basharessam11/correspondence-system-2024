<?php 

// Check If Code Exist
if (mysqli_query($conn, "SELECT * FROM `codes` WHERE `code` = '$text'")->num_rows > 0) {
    // Code Founded
    $code = mysqli_query($conn, "SELECT * FROM `codes` WHERE `code` = '$text'")->fetch_assoc();

    // Check If Code Used 
    if ($code['is_used'] == 1) {
        // Code Useded
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'parse_mode' => 'markdown',
            'text' => '
*هذا الكود مستخدم من قبل يمكنك الحصول علي كود جديد من خلال المتجر*
            ',
            'reply_markup' => $main_menu3
        ]);
    } else {
        // Code First Use
        # Make Code Used
        if (mysqli_query($conn, "UPDATE `codes` SET `is_used` = 1, `user_id` = '$chat_id' WHERE `id` = '{$code['id']}'")) {
            # Add Code Days To The User
            $user_data = mysqli_query($conn, "SELECT * FROM `data` WHERE `user_id` = '$chat_id'")->fetch_assoc();
            $new_days = $user_data['days'] + $code['days'];
            mysqli_query($conn, "UPDATE `data` SET `days` = '$new_days' WHERE `user_id` = '$chat_id'");
    

            bot('sendMessage', [
                'chat_id' => $chat_id,
                'parse_mode' => 'markdown',
                'text' => '
*تم تحديث الإشتراك بنجاح*
                ',
                'reply_markup' => $main_menu2
            ]);
        }
    }
} else {
    // Code Not Founded
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'parse_mode' => 'markdown',
        'text' => '
*لقد أخل كود إشتراك غير صحيح يمكنك طلب إشتراك من متجرنا*
        ',
        'reply_markup' => $main_menu3
    ]);
}

?>