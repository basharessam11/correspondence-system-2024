<?php 

$options = json_encode([
    "inline_keyboard" => [
        [
            [
                "text" => "3 MG",
                "callback_data" => "3mg"
            ],
            [
                "text" => "6 MG",
                "callback_data" => "6mg"
            ],
            [
                "text" => "10 MG",
                "callback_data" => "10mg"
            ]
        ],
        [
            [
                "text" => "إعادة التعين",
                "callback_data" => "reset"
            ],
            [
                "text" => "تفعيل الكل",
                "callback_data" => "all_p"
            ]
        ],
        [
            [
                "text" => "عودة للقائمة الرئيسية ↩️",
                "callback_data" => "back"
            ]
        ]
    ]
]);


// Check If User Not In DB
if (mysqli_query($conn, "SELECT * FROM `data` WHERE `user_id` = '$chat_id2'")->num_rows == 0) {
    // Add New User
    mysqli_query($conn, "INSERT INTO `data` (`user_id`) VALUES ('$chat_id2')");
}

bot('sendMessage', [
    'chat_id' => $chat_id2,
    'parse_mode' => 'markdown',
    'text' => 'من فضلك قم بإختيار المنتجات التي تريد البوت إشعارك عند توافرها 
*" حسب كمية النيكوتين "*',
    'reply_markup' => $options
]);

?>