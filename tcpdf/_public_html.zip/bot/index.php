<?php

require_once 'config.php';

// Starting Message
if ($text == '/start') {
    bot('sendPhoto', [
        'chat_id' => $chat_id,
        'parse_mode' => 'markdown',
        'photo' => 'https://tebo.alwaysdata.net/image.webp',
        'caption' => '*مرحباً بك البوت يقوم بمراقبة منتجات DZRT ويقوم بإشعارك عند توافر المنتجات. كيف يمكنني مساعدتك؟*',
        'resize_keyboard' => true,
        'reply_markup' => $main_menu
    ]);

    $result = mysqli_query($conn, "SELECT * FROM `data` WHERE `user_id` = '$chat_id'");
    if (mysqli_num_rows($result) == 0) {
        mysqli_query($conn, "INSERT INTO `data` (`user_id`) VALUES ('$chat_id')");
    }
}

// Contact Support
if ($data == 'support') {
    bot('deleteMessage', [
        'chat_id' => $chat_id2,
        'message_id' => $message2,
    ]);
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '*للإستفسارات و الدعم الفني يمكنك التواصل عبر* @IF88I',
        'reply_markup' => $main_menu2
    ]);
}

// Back To Main Menu
if ($data == 'back') {
    bot('deleteMessage', [
        'chat_id' => $chat_id2,
        'message_id' => $message2,
    ]);
    bot('sendPhoto', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'photo' => 'https://tebo.alwaysdata.net/image.webp',
        'caption' => '*القائمة الرئيسية:*',
        'reply_markup' => $main_menu
    ]);
}

// Bot Group
if ($data == 'group') {
    bot('deleteMessage', [
        'chat_id' => $chat_id2,
        'message_id' => $message2,
    ]);
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '*إنضم الي المجموعة الخاصة بالبوت *',
        'reply_markup' => $main_menu2
    ]);
}

// Activate Subscribe
if ($data == 'subscribe') {
    bot('deleteMessage', [
        'chat_id' => $chat_id2,
        'message_id' => $message2,
    ]);
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*يرجى كتابة كود الإشتراك*
اذهب إلى المتجر الإلكتروني. 
- وأكمل عملية الدفع 
- عقب الشراء، ستجد كودًا خاصًا ضمن الايميل أو رسالة نصية تصلك من متجر سلة
- نسخ الكود المعروض. 
- افتح البوت وقم بلصق الكود مباشرةً لتفعيل الاشتراك.
        ',
        'reply_markup' => $main_menu3
    ]);
}

// Subscribe Informations
if ($data == 'sub_info') {
    bot('deleteMessage', [
        'chat_id' => $chat_id2,
        'message_id' => $message2,
    ]);

    require_once 'subscribe.php';

    
}

// Activate 1 Day Trial
if ($data == 'actvate1Day') {
    bot('deleteMessage', [
        'chat_id' => $chat_id2,
        'message_id' => $message2,
    ]);
    require_once 'trial.php';
}

// Activate Code Logic
if (str_contains($text, 'SUB')) {
    bot('deleteMessage', [
        'chat_id' => $chat_id2,
        'message_id' => $message2,
    ]);
    require_once 'activate.php';
}

// Notifications
if ($data == 'notifications') {
    
    bot('deleteMessage', [
        'chat_id' => $chat_id2,
        'message_id' => $message2,
    ]);
    require_once 'notifications.php';

}

// Reset All Notifications
if ($data == 'reset') {
    require_once 'notify/reset.php';
}

// Allow All Notifications
if ($data == 'all_p') {
    require_once 'notify/all.php';
}

// Only 3mg Notifications
if ($data == '3mg') {
    require_once 'notify/3mg.php';
}

// Only 6mg Notifications
if ($data == '6mg') {
    require_once 'notify/6mg.php';
}

// Only 10mg Notifications
if ($data == '10mg') {
    require_once 'notify/10mg.php';
}

// Admin Control Panel
if ($chat_id == $admin || $chat_id2 == $admin || $chat_id == $dev || $chat_id2 == $dev) {

    $admin_options = json_encode([
        "inline_keyboard" => [
            [
                [
                    "text" => "أكواد الإشتراكات 🎟️",
                    "callback_data" => "codes"
                ]
            ],
            [
                [
                    "text" => "عدد المستخدمين 👤",
                    "callback_data" => "users"
                ]
            ],
            [
                [
                    "text" => "إرسال رسالة للجميع 🌍",
                    "callback_data" => "all"
                ]
            ],
            [
                [
                    "text" => "وضع الصيانة 🛑",
                    "callback_data" => "mint"
                ]
            ],
            [
                [
                    "text" => "عودة للقائمة الرئيسية ↩️",
                    "callback_data" => "back"
                ]
            ]
        ]
    ]);

    // Developer Mode
    require_once 'admin/mint.php';

    // Admin Control Panel Menu
    if ($data == 'admin') {
        bot('deleteMessage', [
            'chat_id' => $chat_id2,
            'message_id' => $message2,
        ]);
        bot('sendMessage', [
            'chat_id' => $chat_id2,
            'parse_mode' => 'markdown',
            'text' => '*لوحة التحكم :*',
            'reply_markup' => $admin_options
        ]);
    }

    // Count All Users
    if ($data == 'users') {
        require_once 'admin/users.php';
    }

    // Send Message To All Users
    if ($data == 'all') {

        bot('deleteMessage', [
            'chat_id' => $admin,
            'message_id' => $message2,
        ]);
        bot('sendMessage', [
            'chat_id' => $chat_id2,
            'parse_mode' => 'markdown',
            'text' => '* من فضلك قم بكتابة الرسالة التي تريد إرسالها لجميع المستخدمين داخل  أقواس *
مثل :
(السلام عليكم و رحمة الله و بركاتة)',
            'reply_markup' => $admin_options

        ]);
    }

    // Send Message To All Users Logic
    if (str_contains($text, '(')) {
        require_once 'admin/messages.php';
    }

    // Create Subscribe Codes
    if ($data == 'codes') {
        require_once 'admin/codes.php';
    }

    // Code Durations
    require_once 'admin/durations.php';

}

// Send Notifications

# Site Down
if ($_REQUEST['send'] == 0) {

}

// require_once 'check_send.php';

?>