<?php 


$options = json_encode([
    "inline_keyboard" => [
        [
            [
                "text" => "3 MG",
                "callback_data" => "3mg"
            ],
            [
                "text" => "6 MG",
                "callback_data" => "6mg"
            ],
            [
                "text" => "10 MG",
                "callback_data" => "10mg"
            ]
        ],
        [
            [
                "text" => "إعادة التعين",
                "callback_data" => "reset"
            ],
            [
                "text" => "تفعيل الكل",
                "callback_data" => "all_p"
            ]
        ],
        [
            [
                "text" => "عودة للقائمة الرئيسية ↩️", "callback_data" => "back"
            ]
        ]
    ]
]);

bot('deleteMessage', [
    'chat_id' => $chat_id2,
    'message_id' => $message2,
]);

// Set 10MG ON
mysqli_query($conn, "UPDATE `data` SET `p3` = 1, `p4` = 1, `p8` = 1, `10mg` = 1 WHERE `user_id` = '$chat_id2'");

bot('sendMessage', [
    'chat_id' => $chat_id2,
    'parse_mode' => 'markdown',
    'text' => 'سيتم إشعارك عند توافر
*( ايسي رش -  سي سايد فورست - هايلاند بيريز )*',
    'reply_markup' => $options
]);
?>