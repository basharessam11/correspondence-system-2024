<?php 


$options = json_encode([
    "inline_keyboard" => [
        [
            [
                "text" => "3 MG",
                "callback_data" => "3mg"
            ],
            [
                "text" => "6 MG",
                "callback_data" => "6mg"
            ],
            [
                "text" => "10 MG",
                "callback_data" => "10mg"
            ]
        ],
        [
            [
                "text" => "إعادة التعين",
                "callback_data" => "reset"
            ],
            [
                "text" => "تفعيل الكل",
                "callback_data" => "all_p"
            ]
        ],
        [
            [
                "text" => "عودة للقائمة الرئيسية ↩️", "callback_data" => "back"
            ]
        ]
    ]
]);

bot('deleteMessage', [
    'chat_id' => $chat_id2,
    'message_id' => $message2,
]);

// Reset All Options
mysqli_query($conn, "UPDATE `data` SET `p1` = 0, `p2` = 0, `p3` = 0, `p4` = 0, `p5` = 0, `p6` = 0, `p7` = 0, `p8` = 0, `3mg` = 0, `6mg` = 0, `10mg` = 0 WHERE `user_id` = '$chat_id2'");

bot('sendMessage', [
    'chat_id' => $chat_id2,
    'parse_mode' => 'markdown',
    'text' => 'تم إعادة تعين تفضيلاتك
* لن يتم إشعارك بأي منتجات *',
    'reply_markup' => $options
]);

?>