<?php 

$options = json_encode([
    "inline_keyboard" => [
        [
            [
                "text" => "3 MG",
                "callback_data" => "3mg"
            ],
            [
                "text" => "6 MG",
                "callback_data" => "6mg"
            ],
            [
                "text" => "10 MG",
                "callback_data" => "10mg"
            ]
        ],
        [
            [
                "text" => "إعادة التعين",
                "callback_data" => "reset"
            ],
            [
                "text" => "تفعيل الكل",
                "callback_data" => "all_p"
            ]
        ],
        [
            [
                "text" => "عودة للقائمة الرئيسية ↩️", "callback_data" => "back"
            ]
        ]
    ]
]);

bot('deleteMessage', [
    'chat_id' => $chat_id2,
    'message_id' => $message2,
]);

// Reset All Options
mysqli_query($conn, "UPDATE `data` SET `p1` = 1, `p2` = 1, `p3` = 1, `p4` = 1, `p5` = 1, `p6` = 1, `p7` = 1, `p8` = 1, `3mg` = 1, `6mg` = 1, `10mg` = 1 WHERE `user_id` = '$chat_id2'");

bot('sendMessage', [
    'chat_id' => $chat_id2,
    'parse_mode' => 'markdown',
    'text' => 'تم تعين تفضيلاتك
* سيتم إشعارك بكل المنتجات *',
    'reply_markup' => $options
]);

?>