<?php 


$conn = mysqli_connect('localhost', 'u789754942_bot', 'Osamah!@#2004', 'u789754942_bot');

ob_start();

$API_KEY = "7057914543:AAFVs1nVRX9nSw9T-g77eDfGyz3OR2ycHxM";

define('API_KEY', $API_KEY);

function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res, true);
    }
    curl_close($ch);
}

$update = json_decode(file_get_contents("php://input"), true);
$message = $update['message'] ?? null;
$text = $message['text'] ?? '';
$chat_id = $message['chat']['id'] ?? '';
$data = $update['callback_query']['data'] ?? '';
$chat_id2 = $update['callback_query']['message']['chat']['id'] ?? '';
$message2 = $update['callback_query']['message']['message_id'] ?? '';

$admin = 6680513362;
$dev = 6680513362;

if ($chat_id == $admin || $chat_id2 == $admin) {
    $main_menu = json_encode([
        "inline_keyboard" => [
            [["text" => "🔑 اشتراك 🔑", "callback_data" => "subscribe"]],
            [["text" => "🔑 حالة الاشتراك 🔑", "callback_data" => "sub_info"]],
            [["text" => "👍 اشتراك تجريبي لمدة يوم 👍", "callback_data" => "actvate1Day"]],
            [["text" => "🔔 تخصيص التنبيهات 🔔", "callback_data" => "notifications"]],
            [["text" => "🏠 الدخول الي جروب تنبيهات ديزرت 🏠", "callback_data" => "group"]],
            [["text" => "👑لوحة التحكم 👑", "callback_data" => "admin"]]
        ]
    ]);
} else {
    $main_menu = json_encode([
        "inline_keyboard" => [
            [["text" => "🔑 اشتراك 🔑", "callback_data" => "subscribe"]],
            [["text" => "🔑 حالة الاشتراك 🔑", "callback_data" => "sub_info"]],
            [["text" => "👍 اشتراك تجريبي لمدة يوم 👍", "callback_data" => "actvate1Day"]],
            [["text" => "🔔 تخصيص التنبيهات 🔔", "callback_data" => "notifications"]],
            [["text" => "🏠 الدخول الي جروب تنبيهات ديزرت 🏠", "callback_data" => "group"]],
            [["text" => "🎗️ التواصل مع الدعم 🎗️", "callback_data" => "support"]]
        ]
    ]);
}

$main_menu2 = json_encode([
    "inline_keyboard" => [
        [["text" => "عودة للقائمة الرئيسية ↩️", "callback_data" => "back"]]
    ]
]);

$main_menu3 = json_encode([
    "inline_keyboard" => [
        [["text" => "رابط المتجر", "url" => "https://salla.sa/dzrt_noti/mQpEZqW"]],
        [["text" => "عودة للقائمة الرئيسية ↩️", "callback_data" => "back"]]
    ]
]);
?>