<?php

$botUsers = mysqli_query($conn, "SELECT * FROM `data`");
$users = [];
while ($use = $botUsers->fetch_assoc()) {
    $users[] = $use;
}

if ($data == 'mint') {
    $opt = json_encode([
        "inline_keyboard" => [
            [
                [
                    "text" => "تشغيل ✅",
                    "callback_data" => "on"
                ]
            ],
            [
                [
                    "text" => "إيقاف ❌",
                    "callback_data" => "off"
                ]
            ],
            [
                [
                    "text" => "عودة للقائمة السابقة ↩️",
                    "callback_data" => "admin"
                ]
            ]
        ]
    ]);

    bot('deleteMessage', [
        'chat_id' => $chat_id2,
        'message_id' => $message2,
    ]);
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '*تشغيل أو إيقاف وضع الصيانة*',
        'reply_markup' => $opt
    ]);
}

# Off
if ($data == 'off') {

    foreach ($users as $user) {
        bot('deleteMessage', [
            'chat_id' => $user['user_id'],
            'message_id' => $message2,
        ]);
        bot('sendMessage', [
            'chat_id' => $user['user_id'],
            'parse_mode' => 'markdown',
            'text' => '
    *عاد البوت للخدمة بعد عمل صيانة*
            ',
            'reply_markup' => $main_menu2
        ]);

    }
}

# On
if ($data == 'on') {
    foreach ($users as $user) {
        bot('deleteMessage', [
            'chat_id' => $user['user_id'],
            'message_id' => $message2,
        ]);
        bot('sendMessage', [
            'chat_id' => $user['user_id'],
            'parse_mode' => 'markdown',
            'text' => '
    *يتم عمل صيانة حالياً*
            ',
            'reply_markup' => $main_menu2
        ]);
    }
}

?>