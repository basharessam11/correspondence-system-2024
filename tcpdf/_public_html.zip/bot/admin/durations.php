<?php 

$go_back = json_encode([
    "inline_keyboard" => [
        [["text" => "عودة للقائمة السابقة ↩️", "callback_data" => "codes"]]
    ]
]);

bot('deleteMessage', [
    'chat_id' => $chat_id2,
    'message_id' => $message2,
]);
if ($data == 'days_opt') {

    $days_opt = json_encode([
        "inline_keyboard" => [
            [
                [
                    "text" => "1",
                    "callback_data" => "1d"
                ],
                [
                    "text" => "2",
                    "callback_data" => "2d"
                ],
                [
                    "text" => "3",
                    "callback_data" => "3d"
                ],
                [
                    "text" => "4",
                    "callback_data" => "4d"
                ],
                [
                    "text" => "5",
                    "callback_data" => "5d"
                ],
                [
                    "text" => "6",
                    "callback_data" => "6d"
                ]
                ],
                [
                    [
                        "text" => "عودة للقائمة السابقة ↩️",
                        "callback_data" => "codes"
                    ],
                ]
        ]
    ]);
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '*برجاء إختيار مدة الإشتراك : *',
        'reply_markup' => $days_opt
    ]);
}

if ($data == 'weaks_opt') {

      
    $weaks_opt = json_encode([
        "inline_keyboard" => [
            [
                [
                    "text" => "1",
                    "callback_data" => "1w"
                ],
                [
                    "text" => "2",
                    "callback_data" => "2w"
                ],
                [
                    "text" => "3",
                    "callback_data" => "3w"
                ],
            ],
            [
                [
                        "text" => "عودة للقائمة السابقة ↩️",
                    "callback_data" => "codes"
                ],
            ]
        ]
    ]);
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '*برجاء إختيار مدة الإشتراك : *',
        'reply_markup' => $weaks_opt
    ]);
}

if ($data == 'months_opt') {

    $months_opt = json_encode([
        "inline_keyboard" => [
            [
                [
                    "text" => "1",
                    "callback_data" => "1m"
                ],
                [
                    "text" => "2",
                    "callback_data" => "2m"
                ],
                [
                    "text" => "3",
                    "callback_data" => "3m"
                ],
                [
                    "text" => "4",
                    "callback_data" => "4m"
                ],
                [
                    "text" => "5",
                    "callback_data" => "5m"
                ],
                [
                    "text" => "6",
                    "callback_data" => "6m"
                ]
                ],
                [
                    [
                        "text" => "عودة للقائمة السابقة ↩️",
                        "callback_data" => "codes"
                    ],
                ]
        ]
    ]);
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '*برجاء إختيار مدة الإشتراك : *',
        'reply_markup' => $months_opt
    ]);
}

if ($data == '1d') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '1' WHERE `name` = 'admin'");

    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
'reply_markup' => $go_back        

    ]);
}

if ($data == '2d') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '2' WHERE `name` = 'admin'");
    mysqli_query($conn, "UPDATE `options` SET `noti` = '3' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
'reply_markup' => $go_back        
]);
}

if ($data == '3d') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '3' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
'reply_markup' => $go_back        
]);
    
}

if ($data == '4d') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '4' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
'reply_markup' => $go_back        
    ]);
    
}

if ($data == '5d') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '5' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
    
}

if ($data == '6d') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '6' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
    
}

if ($data == '1w') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '7' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
    
}

if ($data == '2w') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '14' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
}

if ($data == '3w') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '21' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
    
}

if ($data == '1m') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '30' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
    
}

if ($data == '2m') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '60' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
   
}

if ($data == '3m') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '90' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
    
}

if ($data == '4m') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '120' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
   
}

if ($data == '5m') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '150' WHERE `name` = 'admin'");
    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
}

if ($data == '6m') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '180' WHERE `name` = 'admin'");

    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
}

if ($data == '1ye') {

    mysqli_query($conn, "UPDATE `options` SET `noti` = '365' WHERE `name` = 'admin'");

    bot('sendMessage', [
        'chat_id' => $chat_id2,
        'parse_mode' => 'markdown',
        'text' => '
*برجاء كتابة عدد الأكواد : *',
    'reply_markup' => $go_back
]);
}

if (is_numeric($text)) {


    $number_of_codes = $text;
    $number_of_days = mysqli_query($conn, "SELECT * FROM `options` WHERE `name` = 'admin'")->fetch_assoc()['noti'];
    
    $all_codes = [];

    while ($number_of_codes > 0) {

        $code = 'SUB' . rand(1000000000000000, 9999999999999999);
        if(mysqli_query($conn, "INSERT INTO `codes` (`code`, `days`) VALUES ('$code', '$number_of_days')")) {
            $all_codes[] = $code;                
        }

        $number_of_codes--;
    }

    $codes_to_send = '';
    foreach ($all_codes as $code) {
        $codes_to_send .= $code. '
';
    }

    bot('sendMessage', [
        'chat_id' => $chat_id,
        'parse_mode' => 'markdown',
        'text' => $codes_to_send,
        'reply_markup' => $go_back        
    ]);

}

?>