<?php 

// Count Users
$total_users = $botUsers->num_rows;


bot('deleteMessage', [
    'chat_id' => $chat_id2,
    'message_id' => $message2,
]);

bot('sendMessage', [
    'chat_id' => $chat_id2,
    'parse_mode' => 'markdown',
    'text' => '* عدد المستخدمين للبوت : ' . $total_users . ' *',
    'reply_markup' => $admin_options
]);

?>