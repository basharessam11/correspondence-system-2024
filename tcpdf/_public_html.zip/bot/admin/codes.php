<?php 

bot('deleteMessage', [
    'chat_id' => $chat_id2,
    'message_id' => $message2,
]);

// Codes Keyboard
$codes_options = json_encode([
    "inline_keyboard" => [
        [
            [
                "text" => "أيام",
                "callback_data" => "days_opt"
            ],
            [
                "text" => "أسابيع",
                "callback_data" => "weaks_opt"
            ],
            [
                "text" => "شهور",
                "callback_data" => "months_opt"
            ]
        ],
        [
            [
                "text" => "سنة واحدة",
                "callback_data" => "1ye"
            ]
        ],
        [
            [
                "text" => "عودة للقائمة السابقة ↩️",
                "callback_data" => "admin"
            ]
        ]
    ]
]);


bot('sendMessage', [
    'chat_id' => $chat_id2,
    'parse_mode' => 'markdown',
    'text' => '*برجاء إختيار مدة الإشتراك : *',
    'reply_markup' => $codes_options
]);

?>