<?php 

$message = str_replace(')', '', str_replace('(', '', $text));

$bot_users = mysqli_query($conn, "SELECT * FROM `data`");

while ($user = $bot_users->fetch_assoc()) {
    bot('sendMessage', [
        'chat_id' => $user['user_id'],
        'parse_mode' => 'markdown',
        'text' => '*' . $message . '*',
    ]);
}


bot('deleteMessage', [
    'chat_id' => $admin,
    'message_id' => $message2,
]);
bot('sendMessage', [
    'chat_id' => $admin,
    'parse_mode' => 'markdown',
    'text' => '* تم إرسال الرسالة للجميع بنجاح *',
    'reply_markup' => $admin_options
]);

?>